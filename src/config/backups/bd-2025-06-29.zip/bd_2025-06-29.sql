-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: bd
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categoria_servicio`
--

DROP TABLE IF EXISTS `categoria_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_servicio` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) NOT NULL,
  `estado` varchar(25) NOT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_servicio`
--

LOCK TABLES `categoria_servicio` WRITE;
/*!40000 ALTER TABLE `categoria_servicio` DISABLE KEYS */;
INSERT INTO `categoria_servicio` VALUES (1,'CARDIOLOGIA','ACT'),(2,'ONCOLOGIA','ACT'),(9,'RADIOGRAFIA','DES'),(100,'CONSULTA GENERAL','ACT'),(101,'Emergencia','ACT'),(102,'Acupuntura','ACT'),(103,'Oftalmología','ACT'),(104,'Odontología','ACT');
/*!40000 ALTER TABLE `categoria_servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita`
--

DROP TABLE IF EXISTS `cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `serviciomedico_id_servicioMedico` int(11) NOT NULL,
  `paciente_id_paciente` int(11) NOT NULL,
  `hora_salida` time NOT NULL,
  `doctor` int(11) NOT NULL,
  PRIMARY KEY (`id_cita`,`paciente_id_paciente`),
  KEY `fk_cita_serviciomedico1_idx` (`serviciomedico_id_servicioMedico`),
  KEY `fk_cita_paciente1_idx` (`paciente_id_paciente`),
  CONSTRAINT `fk_cita_paciente1` FOREIGN KEY (`paciente_id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cita_serviciomedico1` FOREIGN KEY (`serviciomedico_id_servicioMedico`) REFERENCES `serviciomedico` (`id_servicioMedico`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita`
--

LOCK TABLES `cita` WRITE;
/*!40000 ALTER TABLE `cita` DISABLE KEYS */;
INSERT INTO `cita` VALUES (41,'2025-04-02','12:33:00','ACT',24,23,'00:00:00',0),(42,'2025-04-02','12:33:00','ACT',25,23,'00:00:00',0),(43,'2025-04-02','12:33:00','ACT',22,23,'00:00:00',0),(44,'2025-04-02','12:33:00','ACT',22,23,'00:00:00',0),(45,'2025-04-21','22:00:00','Realizadas',26,25,'00:00:00',0),(46,'2025-04-25','12:00:00','Pendiente',27,25,'00:00:00',0),(47,'2025-05-05','20:00:00','Realizadas',26,25,'00:00:00',0),(48,'2025-05-12','20:00:00','Pendiente',26,23,'00:00:00',0),(49,'2025-06-02','20:00:00','Pendiente',24,25,'21:00:00',0),(50,'2025-06-02','21:00:00','Pendiente',24,25,'21:00:00',0),(51,'2025-06-02','22:00:00','Pendiente',24,25,'22:05:00',0),(52,'2025-06-02','22:10:00','Pendiente',24,25,'23:05:00',0),(53,'2025-06-09','20:00:00','Pendiente',24,25,'21:05:00',0),(54,'2025-06-09','21:11:00','Pendiente',24,25,'22:05:00',0),(55,'2025-06-16','20:00:00','Pendiente',24,34,'21:06:00',0),(56,'2025-06-20','10:05:00','Pendiente',24,25,'11:06:00',0),(57,'2025-06-27','10:00:00','Pendiente',24,25,'11:06:00',0),(58,'2025-06-27','11:07:00','Pendiente',24,25,'12:06:00',0),(59,'2025-06-27','12:07:00','Pendiente',24,25,'13:06:00',0),(60,'2025-07-04','10:00:00','Pendiente',24,25,'11:06:00',0),(61,'2025-07-04','11:07:00','Pendiente',24,25,'12:06:00',0),(62,'2025-07-11','10:00:00','Pendiente',24,25,'11:06:00',0),(63,'2025-07-28','20:00:00','Pendiente',24,25,'21:06:00',19),(64,'2025-07-25','10:00:00','Pendiente',24,25,'11:06:00',20);
/*!40000 ALTER TABLE `cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `control`
--

DROP TABLE IF EXISTS `control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control` (
  `id_control` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `diagnostico` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `medicamentosRecetados` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fecha_control` datetime NOT NULL,
  `fechaRegreso` date NOT NULL,
  `nota` varchar(40) NOT NULL,
  `historiaclinica` text NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `severidad` enum('LEVE','MODERADA','GRAVE') DEFAULT 'LEVE',
  PRIMARY KEY (`id_control`),
  KEY `id_paciente` (`id_paciente`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `control_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control`
--

LOCK TABLES `control` WRITE;
/*!40000 ALTER TABLE `control` DISABLE KEYS */;
INSERT INTO `control` VALUES (26,23,1,'El chico presenta dificultad para respirar, hinchazón en el cuerpo y dolores de cabeza','Cetirizina\r\nSalbutamol\r\nAcetaminofén','2025-04-02 14:37:34','2025-04-26','Debe hacerse hematología completa','historia denose','ACT','LEVE'),(27,24,1,'La paciente presenta severos dolores de cabeza, lo cual da a entender que tiene episodios de jaqueca, a su vez también presenta problemas con la visión y mareos\r\nTomar mucha agua','Diclofenac potasico\r\nCafeína\r\nViajesan','2025-04-02 14:45:09','2025-04-23','Tomar mucha agua','historiaclinica','ACT','LEVE'),(28,25,43,'diagnostico','indicaciones','2025-06-10 10:11:51','2026-06-24','nota','historial\r\n\r\n','ACT','LEVE'),(29,25,42,'jfsdjfsdnfds','indicaciones','2025-06-10 20:07:54','2026-06-18','alguito','mhnfdjg algo mas','ACT','LEVE'),(30,25,43,'diagnostivo','indicaciones','2025-06-19 20:29:30','2025-07-06','nota','historial clinico  de algo','ACT','LEVE'),(31,89,42,'este enfermedad crónica','es una indicacion','2025-06-27 19:24:28','2025-06-29','es una nota','este en un historial','ACT','LEVE');
/*!40000 ALTER TABLE `control` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `SALUDABLE` AFTER INSERT ON `control` FOR EACH ROW IF NEW.diagnostico LIKE '%alta médica%' THEN
    UPDATE paciente SET estado_salud = 'SALUDABLE'
    WHERE id_paciente = NEW.id_paciente;
END IF */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `after_control_insert` AFTER INSERT ON `control` FOR EACH ROW BEGIN
    DECLARE enfermedad_cronica BOOLEAN;
    
    
    SET enfermedad_cronica = (NEW.diagnostico LIKE '%crónic%' OR NEW.diagnostico LIKE '%permanente%');
    
    
    IF NEW.severidad = 'GRAVE' OR enfermedad_cronica THEN
        UPDATE paciente 
        SET estado_salud = IF(enfermedad_cronica, 'CRONICO', 'ENFERMO')
        WHERE id_paciente = NEW.id_paciente;
    ELSEIF NEW.severidad IN ('LEVE', 'MODERADA') THEN
        UPDATE paciente 
        SET estado_salud = 'ENFERMO'
        WHERE id_paciente = NEW.id_paciente;
    END IF;
    
    
    INSERT INTO historial_estados (id_paciente, estado_anterior, estado_nuevo, fecha_cambio)
    VALUES (NEW.id_paciente, 
            (SELECT estado_salud FROM paciente WHERE id_paciente = NEW.id_paciente),
            IF(NEW.severidad = 'GRAVE' OR enfermedad_cronica, 
               IF(enfermedad_cronica, 'CRONICO', 'ENFERMO'),
               'ENFERMO'),
            NOW());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `distribucion_edad_genero`
--

DROP TABLE IF EXISTS `distribucion_edad_genero`;
/*!50001 DROP VIEW IF EXISTS `distribucion_edad_genero`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `distribucion_edad_genero` AS SELECT
 1 AS `rango_edad`,
  1 AS `masculino`,
  1 AS `femenino`,
  1 AS `total`,
  1 AS `total_masculino`,
  1 AS `total_femenino` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `entrada`
--

DROP TABLE IF EXISTS `entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) NOT NULL,
  `numero_de_lote` int(16) NOT NULL,
  `fechaDeIngreso` date NOT NULL,
  `estado` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `entrada_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada`
--

LOCK TABLES `entrada` WRITE;
/*!40000 ALTER TABLE `entrada` DISABLE KEYS */;
INSERT INTO `entrada` VALUES (38,6,1,'2025-04-05','ACT'),(39,7,2,'2025-04-06','ACT'),(40,6,3435,'2025-04-21','ACT'),(41,6,3435,'2025-04-21','ACT'),(42,7,3456,'2025-04-21','ACT'),(43,6,1233,'2025-04-21','ACT'),(44,7,3232,'2025-04-29','ACT'),(45,7,3232,'2025-04-29','ACT'),(46,7,3232,'2025-04-29','ACT'),(47,7,3232,'2025-04-29','ACT'),(48,6,3232,'2025-05-02','ACT'),(49,7,1212,'2025-05-02','ACT'),(50,6,2334,'2025-05-02','ACT'),(51,7,2323,'2025-05-05','ACT'),(52,7,4553,'2025-05-05','ACT'),(53,7,4553,'2025-05-05','DES'),(54,7,2323,'2025-05-07','ACT'),(55,6,2323,'2025-05-08','ACT'),(56,6,2323,'2025-05-08','ACT'),(57,6,1212,'2025-05-08','ACT'),(58,6,5664,'2025-05-22','ACT'),(59,7,8098,'2025-06-10','ACT'),(61,7,5656,'2025-06-20','ACT'),(62,7,1234,'2025-06-21','ACT'),(63,6,5651,'2025-06-21','ACT'),(64,7,2134,'2025-06-21','ACT'),(65,7,2134,'2025-06-21','ACT'),(66,6,2134,'2025-06-21','ACT'),(67,7,3012,'2025-06-21','ACT'),(68,7,4532,'2025-06-21','ACT'),(69,7,2342,'2025-06-21','ACT'),(70,7,1223,'2025-06-21','ACT'),(71,6,4564,'2025-06-21','DES');
/*!40000 ALTER TABLE `entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrada_insumo`
--

DROP TABLE IF EXISTS `entrada_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada_insumo` (
  `id_entradaDeInsumo` int(11) NOT NULL AUTO_INCREMENT,
  `id_insumo` int(11) NOT NULL,
  `id_entrada` int(11) NOT NULL,
  `fechaDeVencimiento` date NOT NULL,
  `precio` decimal(12,2) NOT NULL,
  `cantidad_entrante` int(12) NOT NULL,
  `cantidad_disponible` int(12) NOT NULL,
  PRIMARY KEY (`id_entradaDeInsumo`),
  KEY `id_insumo` (`id_insumo`),
  KEY `id_entrada` (`id_entrada`),
  CONSTRAINT `entrada_insumo_ibfk_1` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `entrada_insumo_ibfk_2` FOREIGN KEY (`id_entrada`) REFERENCES `entrada` (`id_entrada`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada_insumo`
--

LOCK TABLES `entrada_insumo` WRITE;
/*!40000 ALTER TABLE `entrada_insumo` DISABLE KEYS */;
INSERT INTO `entrada_insumo` VALUES (52,37,58,'2025-05-25',9.00,89,84),(53,36,59,'2026-02-11',79.00,34,17),(54,41,62,'2026-06-29',9.00,20,19),(55,42,63,'2025-06-27',8.00,12,12),(56,36,64,'2026-06-21',12.00,1,1),(57,36,65,'2026-06-21',12.00,1,1),(58,31,66,'2026-06-21',12.00,1,0),(59,37,67,'2025-06-29',13.00,2,2),(60,31,68,'2027-06-21',120.00,9,7),(61,41,69,'2025-06-29',12.00,5,5),(62,36,70,'2025-06-29',12.00,2,2),(63,36,71,'2025-06-29',190.00,1,1);
/*!40000 ALTER TABLE `entrada_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidad` (
  `id_especialidad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_especialidad`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
INSERT INTO `especialidad` VALUES (3,'Cardiología','ACT'),(4,'Paramedico','ACT'),(5,'Enfermeria','ACT'),(6,'administrador','DES'),(7,'Cirugia','ACT');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `especialidades_solicitadas`
--

DROP TABLE IF EXISTS `especialidades_solicitadas`;
/*!50001 DROP VIEW IF EXISTS `especialidades_solicitadas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `especialidades_solicitadas` AS SELECT
 1 AS `especialidad`,
  1 AS `fecha`,
  1 AS `total_solicitudes` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS `factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `total` float(12,2) NOT NULL,
  `estado` varchar(10) NOT NULL,
  `paciente_id_paciente` int(11) NOT NULL,
  PRIMARY KEY (`id_factura`,`paciente_id_paciente`),
  KEY `fk_factura_paciente1_idx` (`paciente_id_paciente`),
  CONSTRAINT `fk_factura_paciente1` FOREIGN KEY (`paciente_id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

LOCK TABLES `factura` WRITE;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` VALUES (57,'2025-04-14',1000.00,'ACT',25),(58,'2025-04-14',1000.00,'ACT',25),(61,'2025-04-21',1123.00,'ACT',25),(62,'2025-04-15',1000.00,'ACT',25),(63,'2025-04-15',1000.00,'ACT',25),(64,'2025-04-16',125.00,'ACT',25),(65,'2025-04-16',125.00,'ACT',25),(66,'2025-04-17',125.00,'ACT',25),(67,'2025-04-17',415.00,'ACT',25),(68,'2025-04-17',158.00,'ACT',25),(69,'2025-04-17',330.00,'ACT',25),(70,'2025-04-17',25.00,'ACT',25),(71,'2025-04-17',430.00,'ACT',25),(72,'2025-04-17',199.00,'ACT',25),(73,'2025-04-17',58.00,'ACT',25),(74,'2025-04-17',58.00,'ACT',25),(75,'2025-04-17',58.00,'ACT',25),(76,'2025-04-17',50.00,'ACT',25),(77,'2025-04-17',75.00,'ACT',25),(78,'2025-04-21',25.00,'ACT',25),(79,'2025-04-21',123.96,'ACT',25),(80,'2025-04-21',103.30,'ACT',25),(81,'2025-04-21',123.96,'ACT',25),(82,'2025-04-21',123.96,'ACT',25),(83,'2025-04-21',10.33,'ACT',25),(84,'2025-04-21',30.99,'ACT',25),(85,'2025-04-21',22.77,'ACT',25),(86,'2025-04-21',16.55,'ACT',25),(87,'2025-04-21',16.55,'ACT',25),(88,'2025-04-21',125.30,'ACT',25),(89,'2025-04-21',35.80,'ACT',25),(90,'2025-04-21',17.90,'ACT',25),(91,'2025-05-01',2129.30,'ACT',23),(92,'2025-05-01',1127.20,'ACT',23),(93,'2025-05-01',1123.00,'ACT',23),(94,'2025-05-01',2.10,'ACT',23),(95,'2025-05-03',182.12,'ACT',25),(96,'2025-05-03',1000.00,'ACT',25),(97,'2025-05-05',129.00,'ACT',25),(98,'2025-05-07',1.20,'ACT',25),(99,'2025-05-07',29.56,'ACT',25),(100,'2025-05-07',30.16,'ACT',25),(101,'2025-05-07',0.60,'ACT',25),(102,'2025-05-07',1230.00,'ACT',25),(103,'2025-05-22',1.00,'ACT',24),(104,'2025-06-09',1000.00,'ACT',25),(105,'2025-06-14',1000.00,'ACT',25),(106,'2025-06-14',1000.00,'ACT',25),(107,'2025-06-14',3000.00,'ACT',25),(108,'2025-06-15',80.00,'ACT',25),(109,'2025-06-15',4000.00,'ACT',25),(110,'2025-06-16',240.00,'ACT',25),(111,'2025-06-16',240.00,'ACT',25),(112,'2025-06-16',240.00,'ACT',25),(113,'2025-06-16',240.00,'ACT',25),(114,'2025-06-16',80.00,'ACT',25),(115,'2025-06-16',80.00,'ACT',25),(116,'2025-06-16',80.00,'ACT',25),(117,'2025-06-16',9.00,'ACT',25),(118,'2025-06-16',240.00,'ACT',25),(119,'2025-06-16',63.00,'ACT',25),(120,'2025-06-16',36.00,'ACT',25),(121,'2025-06-16',80.00,'ACT',25),(122,'2025-06-16',9.00,'ACT',25),(123,'2025-06-16',240.00,'ACT',25),(124,'2025-06-16',240.00,'ACT',25),(125,'2025-06-16',240.00,'ACT',25),(126,'2025-06-16',240.00,'ACT',25),(127,'2025-06-16',240.00,'ACT',25),(128,'2025-06-16',240.00,'ACT',25),(129,'2025-06-16',240.00,'ACT',25),(130,'2025-06-16',240.00,'ACT',25),(131,'2025-06-16',240.00,'ACT',25),(132,'2025-06-16',240.00,'ACT',25),(133,'2025-06-16',240.00,'ACT',25),(134,'2025-06-17',240.00,'ACT',25),(135,'2025-06-17',240.00,'ACT',25),(136,'2025-06-17',80.00,'ACT',25),(137,'2025-06-18',80.00,'ACT',25),(138,'2025-06-18',80.00,'ACT',25),(139,'2025-06-18',80.00,'ACT',25),(140,'2025-06-18',160.00,'ACT',25),(141,'2025-06-18',36.00,'ACT',25),(142,'2025-06-18',80.00,'ACT',25),(143,'2025-06-18',80.00,'ACT',25),(144,'2025-06-18',116.00,'ACT',25),(145,'2025-06-18',80.00,'ACT',25),(146,'2025-06-18',98.00,'ACT',25),(147,'2025-06-19',560.00,'ACT',25),(148,'2025-06-21',9.00,'ACT',25),(149,'2025-06-21',160.00,'ACT',25),(150,'2025-06-22',1000.00,'ACT',25),(151,'2025-06-22',240.00,'Anulada',25),(152,'2025-06-24',29.56,'ACT',25),(153,'2025-06-27',9.00,'ACT',25),(154,'2025-06-28',29.56,'Anulada',25),(155,'2025-06-28',1080.00,'ACT',25),(156,'2025-06-28',29.56,'ACT',25);
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_has_inventario`
--

DROP TABLE IF EXISTS `factura_has_inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_has_inventario` (
  `factura_id_factura` int(11) NOT NULL,
  `id_entradaDeInsumo` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estado` varchar(5) NOT NULL,
  KEY `fk_factura_has_inventario_factura1_idx` (`factura_id_factura`),
  KEY `id_entradaDeInsumo` (`id_entradaDeInsumo`),
  CONSTRAINT `factura_has_inventario_ibfk_2` FOREIGN KEY (`factura_id_factura`) REFERENCES `factura` (`id_factura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `factura_has_inventario_ibfk_3` FOREIGN KEY (`id_entradaDeInsumo`) REFERENCES `entrada_insumo` (`id_entradaDeInsumo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_has_inventario`
--

LOCK TABLES `factura_has_inventario` WRITE;
/*!40000 ALTER TABLE `factura_has_inventario` DISABLE KEYS */;
INSERT INTO `factura_has_inventario` VALUES (117,52,1,'ACT'),(118,52,3,'ACT'),(119,52,3,'ACT'),(119,52,1,'ACT'),(130,53,3,'ACT'),(132,53,3,'ACT'),(133,53,3,'ACT'),(134,53,3,'ACT'),(135,53,3,'ACT'),(136,53,1,'ACT'),(137,53,1,'ACT'),(138,53,1,'ACT'),(139,53,1,'ACT'),(140,53,2,'ACT'),(143,53,1,'ACT'),(144,53,1,'ACT'),(144,52,4,'ACT'),(146,53,1,'ACT'),(146,52,2,'ACT'),(147,53,7,'ACT'),(148,54,1,'ACT'),(149,53,2,'ACT'),(151,53,3,'ACT'),(152,60,1,'ACT'),(153,52,1,'ACT'),(154,60,1,'ACT'),(155,53,1,'ACT'),(156,60,1,'ACT');
/*!40000 ALTER TABLE `factura_has_inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historial_estados`
--

DROP TABLE IF EXISTS `historial_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historial_estados` (
  `id_historial` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `estado_anterior` varchar(20) DEFAULT NULL,
  `estado_nuevo` varchar(20) NOT NULL,
  `fecha_cambio` datetime NOT NULL,
  `id_control` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_historial`),
  KEY `id_paciente` (`id_paciente`),
  KEY `id_control` (`id_control`),
  CONSTRAINT `historial_estados_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`),
  CONSTRAINT `historial_estados_ibfk_2` FOREIGN KEY (`id_control`) REFERENCES `control` (`id_control`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_estados`
--

LOCK TABLES `historial_estados` WRITE;
/*!40000 ALTER TABLE `historial_estados` DISABLE KEYS */;
INSERT INTO `historial_estados` VALUES (1,89,'CRONICO','CRONICO','2025-06-27 19:24:28',NULL,NULL);
/*!40000 ALTER TABLE `historial_estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horario`
--

DROP TABLE IF EXISTS `horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horario` (
  `id_horario` int(11) NOT NULL AUTO_INCREMENT,
  `diaslaborables` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_horario`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horario`
--

LOCK TABLES `horario` WRITE;
/*!40000 ALTER TABLE `horario` DISABLE KEYS */;
INSERT INTO `horario` VALUES (8,'domingo'),(9,'lunes'),(10,'martes'),(11,'miércoles'),(12,'jueves'),(13,'viernes'),(14,'sábado');
/*!40000 ALTER TABLE `horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horarioydoctor`
--

DROP TABLE IF EXISTS `horarioydoctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horarioydoctor` (
  `id_horarioydoctor` int(11) NOT NULL AUTO_INCREMENT,
  `id_personal` int(11) NOT NULL,
  `id_horario` int(11) NOT NULL,
  `horaDeEntrada` time NOT NULL,
  `horaDeSalida` time NOT NULL,
  PRIMARY KEY (`id_horarioydoctor`),
  KEY `id_doctor` (`id_personal`),
  KEY `id_horario` (`id_horario`),
  CONSTRAINT `horarioydoctor_ibfk_1` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id_personal`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `horarioydoctor_ibfk_2` FOREIGN KEY (`id_horario`) REFERENCES `horario` (`id_horario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horarioydoctor`
--

LOCK TABLES `horarioydoctor` WRITE;
/*!40000 ALTER TABLE `horarioydoctor` DISABLE KEYS */;
INSERT INTO `horarioydoctor` VALUES (30,19,9,'20:00:00','23:00:00'),(31,20,13,'10:00:00','13:00:00'),(32,21,9,'10:00:00','12:00:00'),(33,21,11,'11:00:00','17:00:00'),(34,22,9,'10:00:00','13:00:00'),(35,22,10,'14:00:00','16:00:00'),(36,23,13,'09:00:00','10:01:00');
/*!40000 ALTER TABLE `horarioydoctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospitalizacion`
--

DROP TABLE IF EXISTS `hospitalizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hospitalizacion` (
  `id_hospitalizacion` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_hora_inicio` datetime NOT NULL,
  `precio_horas` float DEFAULT NULL,
  `precio_horas_MoEx` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `total_MoEx` float DEFAULT NULL,
  `id_control` int(11) NOT NULL,
  `fecha_hora_final` datetime DEFAULT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_hospitalizacion`),
  KEY `id_control` (`id_control`),
  CONSTRAINT `hospitalizacion_ibfk_1` FOREIGN KEY (`id_control`) REFERENCES `control` (`id_control`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospitalizacion`
--

LOCK TABLES `hospitalizacion` WRITE;
/*!40000 ALTER TABLE `hospitalizacion` DISABLE KEYS */;
INSERT INTO `hospitalizacion` VALUES (11,'2025-04-28 18:37:52',0,NULL,0,NULL,27,'0000-00-00 00:00:00','DES'),(12,'2025-04-28 18:42:13',0,NULL,0,NULL,26,'0000-00-00 00:00:00','DES'),(13,'2025-04-29 07:32:00',0,NULL,1,NULL,27,'0000-00-00 00:00:00','Realizadas'),(14,'2025-05-23 08:17:49',0,0,0,0,26,'2025-06-28 03:51:02','Pendiente'),(15,'2025-06-10 20:20:19',0,0,0,0,29,'0000-00-00 00:00:00','DES'),(16,'2025-06-21 19:36:00',0,0,0,0,30,'0000-00-00 00:00:00','DES'),(17,'2025-06-21 19:48:25',0,0,0,0,30,'0000-00-00 00:00:00','DES');
/*!40000 ALTER TABLE `hospitalizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumo` (
  `id_insumo` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `descripcion` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `marca` varchar(35) NOT NULL,
  `medida` varchar(35) NOT NULL,
  `precio` float(12,2) NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `stockMinimo` int(11) NOT NULL,
  PRIMARY KEY (`id_insumo`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (24,'','Paracetamol','El paracetamol, también conocido como acetaminofén o acetaminofeno, es un fármaco con propiedades analgésicas y antipiréticas utilizado principalmente para tratar la fiebre y el dolor leve y moderado','','',10.33,'DES',0),(25,'','Ibuprofeno','El ibuprofeno es un antinflamatorio no esteroideo (AINE) que pertenece al subgrupo de fármacos derivados del ácido propiónico.','','',17.90,'DES',0),(29,'2025-04-29_1745911425_WhatsApp Image 2025-04-03 at 11.51.47 PM.jpeg','Ibuprofeno','descripción','','',2.10,'DES',0),(30,'2025-05-02_1746200226_9amALQfcTkJsr2zlMRcpi99AnctFZBjlnRxibrip.jpg','Ibuprofeno','descripción','','',2.10,'DES',0),(31,'2025-05-02_1746216592_img27.jpg','Insumo','Es un antinflamatorio son derivados del ácido propiónico.','Tecno spar 30212 ','400 ml',29.56,'ACT',1),(32,'2025-05-05_1746489843_img23.jpg','Lobo','Es un lobo malvado','Tecno spar 30212 ','400 ml',0.60,'DES',1),(33,'2025-05-07_1746668110_img16.jpg','Spidermas','Es un antinflamatorio son derivados del ácido propiónico.','Tecno spar 30212 ','600 ml',123.00,'ACT',1),(34,'2025-05-08_1746714309_img5.jpg','Caballero','El ibuprofeno es un antinflamaupo de fármacos derivados del ácido propiónico.','Tecno spar 30212','600 ml',2040.00,'DES',1),(35,'2025-05-08_1746715177_img29.jpg','Insumodolar','Es un antinflamatorio son derivados del ácido propiónico.','Tecno spar 30212 ','200 ml',870.00,'DES',5),(36,'2025-06-21_1750492799_img30.png','Ansumo','El ibuprofeno e','Tecno spar 3022 ','400 ml',80.00,'ACT',2),(37,'2025-05-22_1747932563_img16.jpg','Spiderman','descripcio1','Spidermas','100 g',9.00,'ACT',1),(39,'2025-06-20_1750445529_4992462.jpg','Carlos','es un SO ','Microsoft','1 g',5.00,'ACT',1),(40,'2025-06-21_1750492468_Neon03.jpg','Disparador','es una descripcion','Lenovo','1 g',9.00,'ACT',5),(41,'2025-06-21_1750492543_Neon03.jpg','Disparador','es una descripcion','Lenovo','1 g',9.00,'ACT',5),(42,'2025-06-21_1750492723_1259289.jpg','Card','es una descripcion','Microsoft','1 g',8.00,'DES',5);
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumodehospitalizacion`
--

DROP TABLE IF EXISTS `insumodehospitalizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumodehospitalizacion` (
  `id_insumoDeHospitalizacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_hospitalizacion` int(11) NOT NULL,
  `id_inventario` int(11) NOT NULL,
  `cantidad` int(13) NOT NULL,
  PRIMARY KEY (`id_insumoDeHospitalizacion`),
  KEY `id_hospitalizacion` (`id_hospitalizacion`),
  KEY `id_insumo` (`id_inventario`),
  CONSTRAINT `insumodehospitalizacion_ibfk_1` FOREIGN KEY (`id_hospitalizacion`) REFERENCES `hospitalizacion` (`id_hospitalizacion`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `insumodehospitalizacion_ibfk_2` FOREIGN KEY (`id_inventario`) REFERENCES `entrada_insumo` (`id_entradaDeInsumo`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumodehospitalizacion`
--

LOCK TABLES `insumodehospitalizacion` WRITE;
/*!40000 ALTER TABLE `insumodehospitalizacion` DISABLE KEYS */;
INSERT INTO `insumodehospitalizacion` VALUES (13,16,58,1),(14,17,52,2);
/*!40000 ALTER TABLE `insumodehospitalizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `insumos`
--

DROP TABLE IF EXISTS `insumos`;
