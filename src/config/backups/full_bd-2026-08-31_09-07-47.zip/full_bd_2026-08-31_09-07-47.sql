-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: bd
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='mysql-bin.000346', MASTER_LOG_POS=385;

--
-- GTID to start replication from
--

-- SET GLOBAL gtid_slave_pos='0-1-71386';

--
-- Table structure for table `categoria_servicio`
--

DROP TABLE IF EXISTS `categoria_servicio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria_servicio` (
  `id_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) NOT NULL,
  `estado` varchar(25) NOT NULL,
  PRIMARY KEY (`id_categoria`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria_servicio`
--

LOCK TABLES `categoria_servicio` WRITE;
/*!40000 ALTER TABLE `categoria_servicio` DISABLE KEYS */;
INSERT INTO `categoria_servicio` VALUES (1,'CARDIOLOGIA','ACT'),(2,'ONCOLOGIA','ACT'),(9,'RADIOGRAFIA','DES'),(100,'CONSULTA GENERAL','ACT'),(101,'Emergencia','DES'),(102,'Acupuntura','DES'),(103,'Oftalmología','DES'),(104,'Odontología','ACT'),(105,'Hello','DES'),(106,'Categorizacion','DES'),(109,'Xxx','DES'),(110,'ASS','DES'),(111,'Aqw','DES'),(112,'Qss','ACT'),(113,'CAtegor','DES'),(114,'Weeew','ACT'),(115,'Prueba','ACT');
/*!40000 ALTER TABLE `categoria_servicio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita`
--

DROP TABLE IF EXISTS `cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `serviciomedico_id_servicioMedico` int(11) NOT NULL,
  `paciente_id_paciente` int(11) NOT NULL,
  `hora_salida` time NOT NULL,
  `doctor` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_cita`,`paciente_id_paciente`),
  KEY `fk_cita_serviciomedico1_idx` (`serviciomedico_id_servicioMedico`),
  KEY `fk_cita_paciente1_idx` (`paciente_id_paciente`),
  CONSTRAINT `fk_cita_paciente1` FOREIGN KEY (`paciente_id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cita_serviciomedico1` FOREIGN KEY (`serviciomedico_id_servicioMedico`) REFERENCES `serviciomedico` (`id_servicioMedico`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita`
--

LOCK TABLES `cita` WRITE;
/*!40000 ALTER TABLE `cita` DISABLE KEYS */;
INSERT INTO `cita` VALUES (41,'2025-04-02','12:33:00','ACT',24,23,'00:00:00',0,'2026-06-03 20:07:05'),(42,'2025-04-02','12:33:00','ACT',25,23,'00:00:00',0,'2026-06-03 20:07:05'),(43,'2025-04-02','12:33:00','ACT',22,23,'00:00:00',0,'2026-06-03 20:07:05'),(44,'2025-04-02','12:33:00','ACT',22,23,'00:00:00',0,'2026-06-03 20:07:05'),(45,'2025-04-21','22:00:00','Realizadas',26,25,'00:00:00',0,'2026-06-03 20:07:05'),(46,'2025-04-25','12:00:00','Pendiente',27,25,'00:00:00',0,'2026-06-03 20:07:05'),(47,'2025-05-05','20:00:00','Realizadas',26,25,'00:00:00',0,'2026-06-03 20:07:05'),(48,'2025-05-12','20:00:00','Pendiente',26,23,'00:00:00',0,'2026-06-03 20:07:05'),(49,'2025-06-02','20:00:00','Pendiente',24,25,'21:00:00',0,'2026-06-03 20:07:05'),(50,'2025-06-02','21:00:00','Pendiente',24,25,'21:00:00',0,'2026-06-03 20:07:05'),(51,'2025-06-02','22:00:00','Pendiente',24,25,'22:05:00',0,'2026-06-03 20:07:05'),(52,'2025-06-02','22:10:00','Pendiente',24,25,'23:05:00',0,'2026-06-03 20:07:05'),(53,'2025-06-09','20:00:00','Pendiente',24,25,'21:05:00',0,'2026-06-03 20:07:05'),(54,'2025-06-09','21:11:00','Pendiente',24,25,'22:05:00',0,'2026-06-03 20:07:05'),(55,'2025-06-16','20:00:00','Pendiente',24,34,'21:06:00',0,'2026-06-03 20:07:05'),(56,'2025-06-20','10:05:00','Pendiente',24,25,'11:06:00',0,'2026-06-03 20:07:05'),(57,'2025-06-27','10:00:00','Pendiente',24,25,'11:06:00',0,'2026-06-03 20:07:05'),(58,'2025-06-27','11:07:00','Pendiente',24,25,'12:06:00',0,'2026-06-03 20:07:05'),(59,'2025-06-27','12:07:00','Pendiente',24,25,'13:06:00',0,'2026-06-03 20:07:05'),(60,'2025-07-04','10:00:00','Pendiente',24,25,'11:06:00',0,'2026-06-03 20:07:05'),(61,'2025-07-04','11:07:00','Pendiente',24,25,'12:06:00',0,'2026-06-03 20:07:05'),(62,'2025-07-11','10:00:00','Pendiente',24,25,'11:06:00',0,'2026-06-03 20:07:05'),(63,'2025-07-28','20:00:00','Pendiente',24,25,'21:06:00',19,'2026-06-03 20:07:05'),(64,'2025-07-25','10:00:00','Pendiente',24,25,'11:06:00',20,'2026-06-03 20:07:05'),(65,'2025-09-29','20:00:00','Pendiente',24,25,'21:09:00',19,'2026-06-03 20:07:05'),(66,'2025-10-20','20:00:00','DES',24,25,'21:10:00',19,'2026-06-03 20:07:05'),(67,'2025-10-24','10:01:00','DES',24,25,'11:10:00',20,'2026-08-29 20:05:57'),(68,'2025-10-06','20:00:00','Pendiente',24,25,'21:10:00',19,'2026-06-03 20:07:05'),(69,'2025-10-27','20:00:00','DES',24,25,'21:10:00',19,'2026-06-12 01:42:01'),(70,'2025-10-06','20:00:00','Pendiente',24,25,'21:11:00',19,'2026-06-03 20:07:05'),(71,'2026-03-30','20:00:00','Pendiente',24,25,'21:00:00',19,'2026-06-03 20:07:05'),(72,'2026-03-31','14:00:00','Pendiente',25,104,'15:00:00',22,'2026-06-03 20:07:05'),(76,'2026-06-22','20:00:00','Pendiente',26,104,'21:00:00',19,'2026-06-12 01:20:43'),(91,'2026-06-11','05:00:00','DES',24,25,'06:00:00',20,'2026-06-12 01:20:57'),(92,'2026-06-15','21:00:00','Pendiente',24,108,'22:00:00',19,'2026-06-05 00:55:25'),(93,'2026-06-15','22:00:00','Pendiente',24,25,'23:00:00',19,'2026-06-05 00:55:05'),(94,'2026-06-22','21:00:00','Pendiente',24,25,'22:00:00',19,'2026-06-12 01:11:58'),(125,'2026-08-28','10:00:00','DES',24,104,'11:00:00',20,'2026-08-26 22:14:00'),(129,'2026-10-16','10:00:00','Expirado',23,104,'10:01:00',23,'2026-08-23 17:08:03'),(130,'2026-10-26','20:00:00','Expirado',23,104,'21:00:00',19,'2026-08-23 17:08:03'),(131,'2026-08-23','26:01:38','Expirado',38,127,'32:01:38',19,'2026-08-23 17:08:03'),(132,'2026-09-04','12:00:00','Expirado',24,104,'13:00:00',20,'2026-08-23 20:49:25'),(133,'2026-08-27','08:00:00','Expirado',24,104,'09:00:00',20,'2026-08-23 20:49:25'),(134,'2026-08-31','18:53:55','Pendiente',22,83,'21:53:55',19,'2026-08-23 20:55:07'),(135,'2026-10-05','20:00:00','DES',24,117,'21:00:00',19,'2026-08-31 13:04:06'),(136,'2026-09-25','09:00:00','Pendiente',23,104,'10:00:00',23,'2026-08-29 20:05:12'),(137,'2026-09-04','09:00:00','Pendiente',23,104,'10:00:00',23,'2026-08-31 12:32:57'),(138,'2026-09-06','04:00:00','Pendiente',40,104,'05:00:00',62,'2026-08-31 13:04:13');
/*!40000 ALTER TABLE `cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL AUTO_INCREMENT,
  `nacionalidad` varchar(12) NOT NULL,
  `cedula` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `apellido` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `telefono` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `direccion` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fn` date NOT NULL,
  `genero` varchar(16) NOT NULL,
  `estado` varchar(5) NOT NULL,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (1,'V','12098234','Joseswewewe','Lara','04123213212','esuna direccion','2005-10-02','Masculino','DES'),(2,'V','2000002','Editado','Modificado','04123454320','en su casa','2002-02-20','Femenino','ACT'),(3,'V','3722999','Pedro','Perez','04123454327','en su casa','2002-02-20','Masculino','ACT'),(4,'V','30554140','Carlos','Hernadéz','04121232343','Eb su casa','2012-02-11','Masculino','ACT'),(5,'V','30554145','Dixon','Bastias','04142232333','En el Tocuyo','2004-10-08','Masculino','ACT'),(6,'V','30554144','Asss','Hernadéz','04142323232','Estados unidos','2001-08-26','Masculino','ACT'),(7,'V','30554134','Wilmer','Baez','04123232323','Esto es una direccion pero editarda','2000-09-03','Masculino','ACT'),(8,'V','30554143','Asss','Bastias','04123232323','Esto es una direccion pero editarda','2000-08-21','Masculino','ACT'),(9,'V','1223232','Wilmer','Asddd','04142323232','Calle 10 entre 3 y 7','2021-08-27','Masculino','ACT'),(10,'V','1212121','Nombredfmds','Apellidoa','04142232333','Es una direccion ','2000-09-01','Masculino','ACT');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `control`
--

DROP TABLE IF EXISTS `control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `control` (
  `id_control` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `diagnostico` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `medicamentosRecetados` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fecha_control` datetime NOT NULL,
  `fechaRegreso` date NOT NULL,
  `nota` varchar(40) NOT NULL,
  `historiaclinica` text NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `severidad` enum('LEVE','MODERADA','GRAVE') DEFAULT 'LEVE',
  PRIMARY KEY (`id_control`),
  KEY `id_paciente` (`id_paciente`,`id_usuario`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `control_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `control`
--

LOCK TABLES `control` WRITE;
/*!40000 ALTER TABLE `control` DISABLE KEYS */;
INSERT INTO `control` VALUES (26,23,1,'El chico presenta dificultad para respirar, hinchazón en el cuerpo y dolores de cabeza','Cetirizina\r\nSalbutamol\r\nAcetaminofén','2025-04-02 14:37:34','2025-04-26','Debe hacerse hematología completa','2wd','ACT','LEVE'),(27,24,1,'La paciente presenta severos dolores de cabeza, lo cual da a entender que tiene episodios de jaqueca, a su vez también presenta problemas con la visión y mareos\r\nTomar mucha agua','Diclofenac potasicoCafeínaViajesan','2025-04-02 14:45:09','2025-04-23','Tomar mucha agua','Historia bbba','ACT','LEVE'),(28,25,43,'diagnostico','indicaciones','2025-06-10 10:11:51','2026-06-24','nota','historial\r\n\r\n','ACT','LEVE'),(29,25,42,'jfsdjfsdnfds','indicaciones','2025-06-10 20:07:54','2026-06-18','alguito','mhnfdjg algo mas','ACT','LEVE'),(30,25,43,'diagnostivo','indicaciones','2025-06-19 20:29:30','2025-07-06','nota','historial clinico  de algo no se','ACT','LEVE'),(31,89,42,'este enfermedad crónica','es una indicacion','2025-06-27 19:24:28','2025-06-29','es una nota','este en un historialssskjklk','ACT','LEVE'),(32,25,43,'dgdgdgff','gdfgd','2025-09-25 20:24:37','2025-10-12','fghfh','sddsds','ACT','LEVE'),(33,25,1,'diagnostico','indicaciones','2025-10-03 11:23:02','2025-11-01','nota','historial','ACT','LEVE'),(34,25,1,'diagnostico','indicaciones','2025-10-03 11:23:41','2025-11-01','nota editada','historial','ACT','LEVE'),(40,25,43,'diagnostico','sqssssas','2025-10-30 20:12:15','2025-10-31','sqssa','historialsaaaaaasdaslñq','ACT','LEVE'),(41,25,46,'sidasd','','2025-11-01 11:30:10','0000-00-00','','historial','DES','LEVE'),(42,26,46,'fewefewf3r','w3r3w','2025-11-03 14:22:41','2025-11-04','r3wr','edqwdwefw','ACT','MODERADA'),(43,102,43,'dcsdcsdc','dcsdc','2025-11-03 14:37:35','2025-11-11','zd','dcsdcsd','ACT','LEVE'),(44,23,42,'Diadagnostico','Indiadasdicaciones','2025-11-03 14:48:38','2029-02-13','Notalgia\r\n','Hdfdfdstoarial','ACT','LEVE'),(45,102,1,'sdasd','asdas','2025-11-03 15:00:02','2025-11-11','sadas','wdawd','ACT','LEVE'),(46,102,1,'sdakjk','sdakjsjd','2025-11-03 15:01:59','2025-11-04','skadaksd','sadsd','ACT','LEVE'),(47,102,42,'efwfe','efwef','2025-11-03 17:12:57','2025-11-22','edwe','fewf','ACT','LEVE'),(48,102,1,'jkjhjkjkjk','jkjjkjk','2025-11-03 17:15:47','2025-11-19','hjhjhjjhjhj','jkjjkjk','ACT','LEVE'),(49,102,46,'jkhhuhu','hjhjhj','2025-11-03 17:18:04','2025-11-19','bkkuk','hhjhjhjsiiiiioijoijiiojjjjjjjjj','ACT','LEVE'),(50,102,1,'cdsdcsd','vfvffvfv','2025-11-03 17:32:51','2025-11-26','cds','vfvf','ACT','LEVE'),(51,102,43,'xwxxw','xwxwxw','2025-11-03 17:34:08','2025-11-26','wxqx','xwxqx','ACT','MODERADA'),(52,102,1,'nmnmmnmn','m,m,m,m,mnmn','2025-11-03 17:43:31','2025-11-14','mhhhj','mnmnmn','ACT','LEVE'),(53,102,1,'pppppp','pppppp','2025-11-04 10:07:56','2025-11-12','ppppppp','ppppp','ACT','LEVE'),(54,102,43,'dcsdf','dsfsdf','2025-11-04 13:11:48','2025-11-27','kdslkdl','dfsf','ACT','MODERADA'),(55,102,46,'wdddw','swssw','2025-11-04 13:37:49','2025-12-05','swsws','dfsfwd','DES','LEVE'),(56,92,42,'Diagnostivo','','2026-06-21 09:38:55','0000-00-00','','Hoddddfdfds','DES','MODERADA'),(57,92,46,'Sdsdfdfdfds sdds','','2026-06-24 11:03:10','0000-00-00','','Goadsffdff fdsnfdsf','DES','GRAVE'),(58,25,42,'Aqui bien trabajando','','2026-06-27 17:16:58','0000-00-00','','Historial hola','DES','LEVE'),(59,25,42,'Diagnsoti ','','2026-06-28 09:44:52','0000-00-00','','Historial xf','DES','MODERADA'),(60,92,42,'Dioangdsfd','','2026-06-28 10:16:18','0000-00-00','','Hoal fdsdsx','DES','MODERADA'),(61,25,42,'Diagnost','','2026-07-02 06:56:35','0000-00-00','','Sddstorial','DES','MODERADA'),(62,104,42,'Modelo BAse','Modelo BAse','2026-08-23 00:00:00','2026-09-02','Modelo BAse','Modelo base','ACT','LEVE'),(63,104,42,'Modelo BAse','Modelo BAse','2026-08-23 00:00:00','2026-09-02','Modelo BAse','Modelo base','ACT','LEVE'),(64,92,42,'Prueba 1 tiene que se 1','Prueba 1 tiene que se 1','2026-08-23 00:00:00','2026-08-29','Prueba 1 tiene que se 1','Prueba 1 tiene que se 1','ACT','LEVE'),(65,104,42,'Otra prueba','Otra prueba','2026-08-23 00:00:00','2026-09-04','Otra prueba','Otra prueba','ACT','LEVE'),(66,104,42,'Es una broma','Es una broma','2026-08-23 00:00:00','2026-09-05','Es una broma','Es una broma o que\r\n','ACT','LEVE'),(70,104,42,'Es una pruebas','Es una pruebas','2026-08-27 00:00:00','2039-09-05','Es una pruebas','Es una pruebas','ACT','LEVE'),(71,104,46,'Noctoruwqewnedxsad sadfnsf','Noctoruwqewnedxsad sadfnsf','2026-08-27 00:00:00','2026-09-06','Noctoruwqewnedxsad sadfnsf','Noctoruwqewnedxsad sadfnsf','ACT','LEVE'),(72,23,42,'Helllo werr dfkds','Helllo werr dfkds','2026-08-29 00:00:00','2026-09-04','Helllo werr dfkds','Helllo werr dfkds','ACT','LEVE'),(73,92,42,'Es hora de trabajar','','2026-08-29 16:14:39','0000-00-00','','Es hora de trabajar','DES','MODERADA');
/*!40000 ALTER TABLE `control` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `SALUDABLE` AFTER INSERT ON `control` FOR EACH ROW IF NEW.diagnostico LIKE '%alta médica%' THEN




    UPDATE paciente SET estado_salud = 'SALUDABLE'




    WHERE id_paciente = NEW.id_paciente;




END IF */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `detalle_factura`
--

DROP TABLE IF EXISTS `detalle_factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalle_factura` (
  `id_datelle_factura` int(11) NOT NULL AUTO_INCREMENT,
  `id_factura` int(11) NOT NULL,
  `tipo` varchar(35) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` float(12,2) NOT NULL,
  `subtotal` float(12,2) NOT NULL,
  `hospitalizacion_id_hospitalizacion` int(11) DEFAULT NULL,
  `serviciomedico_id_servicioMedico` int(11) DEFAULT NULL,
  `entrada_insumo_id_entradaDeInsumo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_datelle_factura`),
  KEY `id_factura` (`id_factura`),
  KEY `hospitalizacion_id_hospitalizacion` (`hospitalizacion_id_hospitalizacion`,`serviciomedico_id_servicioMedico`,`entrada_insumo_id_entradaDeInsumo`),
  KEY `entrada_insumo_id_entradaDeInsumo` (`entrada_insumo_id_entradaDeInsumo`),
  KEY `serviciomedico_id_servicioMedico` (`serviciomedico_id_servicioMedico`),
  CONSTRAINT `detalle_factura_ibfk_1` FOREIGN KEY (`id_factura`) REFERENCES `factura` (`id_factura`),
  CONSTRAINT `detalle_factura_ibfk_2` FOREIGN KEY (`hospitalizacion_id_hospitalizacion`) REFERENCES `hospitalizacion` (`id_hospitalizacion`),
  CONSTRAINT `detalle_factura_ibfk_3` FOREIGN KEY (`entrada_insumo_id_entradaDeInsumo`) REFERENCES `entrada_insumo` (`id_entradaDeInsumo`),
  CONSTRAINT `detalle_factura_ibfk_4` FOREIGN KEY (`serviciomedico_id_servicioMedico`) REFERENCES `serviciomedico` (`id_servicioMedico`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_factura`
--

LOCK TABLES `detalle_factura` WRITE;
/*!40000 ALTER TABLE `detalle_factura` DISABLE KEYS */;
INSERT INTO `detalle_factura` VALUES (16,213,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(17,225,'Servicio',1,100.00,100.00,NULL,22,NULL),(18,225,'Servicio',1,100.00,100.00,NULL,25,NULL),(19,225,'Servicio',1,100.00,100.00,NULL,25,NULL),(20,225,'Servicio',1,100.00,100.00,NULL,25,NULL),(21,241,'Servicio',1,100.00,100.00,NULL,25,NULL),(22,242,'Servicio',1,1000.00,100.00,NULL,25,NULL),(23,243,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(24,244,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(25,245,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(26,247,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(27,248,'Servicio',1,1000.00,1000.00,NULL,25,NULL),(28,249,'Servicio',1,1000.00,1000.00,NULL,25,NULL);
/*!40000 ALTER TABLE `detalle_factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `distribucion_edad_genero`
--

DROP TABLE IF EXISTS `distribucion_edad_genero`;
/*!50001 DROP VIEW IF EXISTS `distribucion_edad_genero`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `distribucion_edad_genero` AS SELECT
 1 AS `rango_edad`,
  1 AS `masculino`,
  1 AS `femenino`,
  1 AS `total`,
  1 AS `total_masculino`,
  1 AS `total_femenino` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `entrada`
--

DROP TABLE IF EXISTS `entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada` (
  `id_entrada` int(11) NOT NULL AUTO_INCREMENT,
  `id_proveedor` int(11) NOT NULL,
  `numero_de_lote` int(16) NOT NULL,
  `fechaDeIngreso` date NOT NULL,
  `estado` varchar(10) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_entrada`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `entrada_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada`
--

LOCK TABLES `entrada` WRITE;
/*!40000 ALTER TABLE `entrada` DISABLE KEYS */;
INSERT INTO `entrada` VALUES (81,6,21233,'2026-06-13','ACT'),(82,6,2123,'2026-06-14','ACT'),(83,6,2123,'2026-06-28','DES'),(84,6,21233,'2026-06-28','DES'),(85,8,2123,'2026-08-17','ACT'),(86,7,2123,'2026-08-17','DES'),(87,7,2123,'2026-08-17','ACT'),(88,6,212332,'2026-08-17','DES'),(89,6,21233,'2026-08-27','ACT'),(90,11,212300,'2026-08-28','ACT'),(91,6,1212,'2026-08-29','ACT');
/*!40000 ALTER TABLE `entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrada_insumo`
--

DROP TABLE IF EXISTS `entrada_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrada_insumo` (
  `id_entradaDeInsumo` int(11) NOT NULL AUTO_INCREMENT,
  `id_insumo` int(11) NOT NULL,
  `id_entrada` int(11) NOT NULL,
  `fechaDeVencimiento` date NOT NULL,
  `precio` decimal(12,2) NOT NULL,
  `cantidad_entrante` int(12) NOT NULL,
  `cantidad_disponible` int(12) NOT NULL,
  PRIMARY KEY (`id_entradaDeInsumo`),
  KEY `id_insumo` (`id_insumo`),
  KEY `id_entrada` (`id_entrada`),
  CONSTRAINT `entrada_insumo_ibfk_1` FOREIGN KEY (`id_insumo`) REFERENCES `insumo` (`id_insumo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `entrada_insumo_ibfk_2` FOREIGN KEY (`id_entrada`) REFERENCES `entrada` (`id_entrada`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrada_insumo`
--

LOCK TABLES `entrada_insumo` WRITE;
/*!40000 ALTER TABLE `entrada_insumo` DISABLE KEYS */;
INSERT INTO `entrada_insumo` VALUES (73,49,81,'2029-06-11',10000.00,1,0),(74,50,82,'2026-06-24',100.00,12,0),(75,49,83,'2029-07-12',650.00,10,1),(76,49,84,'2026-07-12',65000.00,20,18),(77,49,85,'2039-08-28',111.00,1,1),(78,49,86,'3030-08-17',1212.00,1,1),(79,51,87,'2029-08-02',100.00,12,12),(80,52,88,'2026-09-05',10000.00,100,100),(81,53,89,'2026-09-04',100.00,1,1),(82,51,90,'2026-09-05',600000.00,1,1),(83,49,91,'2026-09-04',12123.00,1,1);
/*!40000 ALTER TABLE `entrada_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidad` (
  `id_especialidad` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `estado` varchar(20) NOT NULL,
  PRIMARY KEY (`id_especialidad`) USING BTREE,
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
INSERT INTO `especialidad` VALUES (3,'Cardiología','DES'),(4,'Paramedico','DES'),(5,'Enfermeria','DES'),(6,'administrador','ACT'),(7,'Cirugia','ACT'),(8,'Especialidad','ACT'),(10,'Wilmer','ACT'),(11,'Sdssd','ACT'),(12,'Asas','ACT'),(13,'Patologia','DES');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `especialidades_solicitadas`
--

DROP TABLE IF EXISTS `especialidades_solicitadas`;
/*!50001 DROP VIEW IF EXISTS `especialidades_solicitadas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `especialidades_solicitadas` AS SELECT
 1 AS `especialidad`,
  1 AS `fecha`,
  1 AS `total_solicitudes` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `factura`
--

DROP TABLE IF EXISTS `factura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura` (
  `id_factura` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `total` float(12,2) NOT NULL,
  `estado` varchar(10) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  PRIMARY KEY (`id_factura`,`id_cliente`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `factura_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

LOCK TABLES `factura` WRITE;
/*!40000 ALTER TABLE `factura` DISABLE KEYS */;
INSERT INTO `factura` VALUES (213,'2026-06-09',0.00,'ACT',5),(216,'2026-08-21',779952.19,'ACT',6),(217,'2026-08-21',857947.44,'ACT',6),(218,'2026-08-21',857947.44,'ACT',6),(219,'2026-08-21',857947.44,'ACT',6),(220,'2026-08-21',857947.44,'ACT',6),(221,'2026-08-21',857947.44,'ACT',6),(222,'2026-08-21',857947.44,'ACT',6),(223,'2026-08-21',857947.44,'ACT',6),(224,'2026-08-21',857947.44,'ACT',6),(225,'2026-08-21',857947.44,'ACT',6),(226,'2026-08-21',857947.44,'ACT',6),(227,'2026-08-21',779952.19,'ACT',6),(228,'2026-08-21',779952.19,'ACT',6),(229,'2026-08-21',779952.19,'ACT',6),(230,'2026-08-21',779952.19,'ACT',6),(231,'2026-08-21',779952.19,'ACT',6),(232,'2026-08-21',779952.19,'ACT',6),(233,'2026-08-21',779952.19,'ACT',6),(234,'2026-08-21',779952.19,'ACT',6),(235,'2026-08-21',779952.19,'ACT',6),(236,'2026-08-21',779952.19,'ACT',6),(237,'2026-08-21',779952.19,'ACT',6),(238,'2026-08-21',779952.19,'ACT',6),(239,'2026-08-21',779952.19,'ACT',6),(240,'2026-08-21',779952.19,'ACT',6),(241,'2026-08-21',779952.19,'ACT',6),(242,'2026-08-21',779952.19,'ACT',6),(243,'2026-08-21',779952.19,'ACT',6),(244,'2026-08-21',779952.19,'ACT',6),(245,'2026-08-21',779952.19,'ACT',6),(246,'2026-08-21',779952.19,'ACT',6),(247,'2026-08-21',779952.19,'ACT',6),(248,'2026-08-21',779952.19,'ACT',6),(249,'2026-08-28',791666.69,'ACT',6);
/*!40000 ALTER TABLE `factura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horario`
--

DROP TABLE IF EXISTS `horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horario` (
  `id_horario` int(11) NOT NULL AUTO_INCREMENT,
  `diaslaborables` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_horario`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horario`
--

LOCK TABLES `horario` WRITE;
/*!40000 ALTER TABLE `horario` DISABLE KEYS */;
INSERT INTO `horario` VALUES (8,'domingo'),(9,'lunes'),(10,'martes'),(11,'miércoles'),(12,'jueves'),(13,'viernes'),(14,'sábado');
/*!40000 ALTER TABLE `horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horarioydoctor`
--

DROP TABLE IF EXISTS `horarioydoctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horarioydoctor` (
  `id_horarioydoctor` int(11) NOT NULL AUTO_INCREMENT,
  `id_personal` int(11) NOT NULL,
  `id_horario` int(11) NOT NULL,
  `horaDeEntrada` time NOT NULL,
  `horaDeSalida` time NOT NULL,
  PRIMARY KEY (`id_horarioydoctor`),
  KEY `id_doctor` (`id_personal`),
  KEY `id_horario` (`id_horario`),
  CONSTRAINT `horarioydoctor_ibfk_1` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id_personal`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `horarioydoctor_ibfk_2` FOREIGN KEY (`id_horario`) REFERENCES `horario` (`id_horario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horarioydoctor`
--

LOCK TABLES `horarioydoctor` WRITE;
/*!40000 ALTER TABLE `horarioydoctor` DISABLE KEYS */;
INSERT INTO `horarioydoctor` VALUES (30,19,9,'20:00:00','23:00:00'),(31,20,13,'10:00:00','13:00:00'),(32,21,9,'10:00:00','12:00:00'),(33,21,11,'11:00:00','17:00:00'),(34,22,9,'10:00:00','13:00:00'),(35,22,10,'14:00:00','16:00:00'),(36,23,13,'09:00:00','10:01:00'),(41,29,10,'00:00:02','10:00:00'),(42,20,12,'02:00:00','23:00:00'),(43,22,12,'01:00:00','23:00:00'),(44,32,8,'00:00:00','01:00:00'),(45,36,8,'00:00:00','01:00:00'),(61,62,8,'00:00:00','05:00:00'),(62,62,9,'00:00:00','05:00:00');
/*!40000 ALTER TABLE `horarioydoctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospitalizacion`
--

DROP TABLE IF EXISTS `hospitalizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hospitalizacion` (
  `id_hospitalizacion` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_hora_inicio` datetime NOT NULL,
  `precio_horas` float DEFAULT NULL,
  `precio_horas_MoEx` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  `total_MoEx` float DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `fecha_hora_final` datetime DEFAULT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `personal_id_personal` int(11) NOT NULL,
  PRIMARY KEY (`id_hospitalizacion`),
  KEY `id_control` (`id_paciente`),
  KEY `id_paciente` (`id_paciente`),
  KEY `personal_id_personal` (`personal_id_personal`),
  CONSTRAINT `hospitalizacion_ibfk_1` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`),
  CONSTRAINT `hospitalizacion_ibfk_2` FOREIGN KEY (`personal_id_personal`) REFERENCES `personal` (`id_personal`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hospitalizacion`
--

LOCK TABLES `hospitalizacion` WRITE;
/*!40000 ALTER TABLE `hospitalizacion` DISABLE KEYS */;
INSERT INTO `hospitalizacion` VALUES (41,'2026-06-21 09:38:55',0,0,0,0,92,'0000-00-00 00:00:00','Realizada',19),(45,'2026-06-27 17:16:58',0,0,0,0,25,'0000-00-00 00:00:00','DES',19),(46,'2026-06-28 09:44:52',0,0,0,0,25,'0000-00-00 00:00:00','',19),(47,'2026-06-28 10:16:18',0,0,0,0,92,'0000-00-00 00:00:00','DES',19),(48,'2026-07-02 06:56:35',0,0,0,0,25,'0000-00-00 00:00:00','Pendiente',19),(49,'2026-08-29 16:14:39',0,0,0,0,92,'0000-00-00 00:00:00','DES',19);
/*!40000 ALTER TABLE `hospitalizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumo` (
  `id_insumo` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(500) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `descripcion` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `marca` varchar(35) NOT NULL,
  `medida` varchar(35) NOT NULL,
  `precio` float(12,2) NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `stockMinimo` int(11) NOT NULL,
  `iva` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_insumo`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (49,'2026-06-13_1781401388_Viernes de escritorio 2.jpg','Wilmer','Aaasdms dsffdsjfsd fdsmf dsmfsf','Marca','200 ml',100.00,'ACT',2,0),(50,'2026-06-21_1782090385_4k-minimalist-wallpaper-14.jpg','Assssss','Aaasdms dsffdsjfsd fdsmf dsmfsf','Marca','100 ml',100.00,'ACT',1,0),(51,'2026-08-27_1787868240_Viernes de escritorio 2.jpg','Chuleta','Aaasdms dsffdsjfsd fdsmf dsmfsf','Marca','200 ml',100.00,'ACT',1,0),(52,'2026-08-17_1787014438_uwp5038865.jpeg','Samurai','Aaasdms dsffdsjfsd fdsmf dsmfsf','Marca de','200 ml',100.00,'ACT',1,0),(53,'2026-08-27_1787872337_toshiro-hitsugaya-de-bleach_3840x2160_xtrafondos.com.jpg','You','En un rol para los doctores','Marca de','200 ml',100.00,'DES',1,0);
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumodehospitalizacion`
--

DROP TABLE IF EXISTS `insumodehospitalizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumodehospitalizacion` (
  `id_insumoDeHospitalizacion` int(11) NOT NULL AUTO_INCREMENT,
  `id_hospitalizacion` int(11) NOT NULL,
  `id_entradaDeInsumo` int(11) NOT NULL,
  `cantidad` int(13) NOT NULL,
  PRIMARY KEY (`id_insumoDeHospitalizacion`),
  KEY `id_hospitalizacion` (`id_hospitalizacion`),
  KEY `id_insumo` (`id_entradaDeInsumo`),
  CONSTRAINT `insumodehospitalizacion_ibfk_1` FOREIGN KEY (`id_hospitalizacion`) REFERENCES `hospitalizacion` (`id_hospitalizacion`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `insumodehospitalizacion_ibfk_2` FOREIGN KEY (`id_entradaDeInsumo`) REFERENCES `entrada_insumo` (`id_entradaDeInsumo`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumodehospitalizacion`
--

LOCK TABLES `insumodehospitalizacion` WRITE;
/*!40000 ALTER TABLE `insumodehospitalizacion` DISABLE KEYS */;
INSERT INTO `insumodehospitalizacion` VALUES (52,47,75,1),(53,48,75,1);
/*!40000 ALTER TABLE `insumodehospitalizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `insumos_estadisticas`
--

DROP TABLE IF EXISTS `insumos_estadisticas`;
/*!50001 DROP VIEW IF EXISTS `insumos_estadisticas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `insumos_estadisticas` AS SELECT
 1 AS `nombre_insumo`,
  1 AS `total_usado` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente` (
  `id_paciente` int(11) NOT NULL AUTO_INCREMENT,
  `nacionalidad` varchar(12) NOT NULL,
  `cedula` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `apellido` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `telefono` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `direccion` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `fn` date NOT NULL,
  `genero` varchar(16) NOT NULL,
  `estado` varchar(5) NOT NULL,
  `estado_salud` enum('SALUDABLE','ENFERMO','CRONICO') DEFAULT 'SALUDABLE',
  PRIMARY KEY (`id_paciente`),
  UNIQUE KEY `cedula` (`cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente`
--

LOCK TABLES `paciente` WRITE;
/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
INSERT INTO `paciente` VALUES (23,'V','28150004','Juan','Silva','04121338031','Calle 10 entre 3 y 7','2001-09-22','Masculino','ACT','SALUDABLE'),(24,'V','28329224','Rocio','Rodriguez','04121338031','URB EL BOSQUE CALLE 12','2025-04-02','Femenino','DES','SALUDABLE'),(25,'V','30554141','Carlosssss','Hernadéz','04121232340','Eb su casa','2012-02-16','Masculino','DES','ENFERMO'),(26,'V','17664525','Sofia','Sofia','4121338031','undefined','2001-03-30','Masculino','DES','SALUDABLE'),(27,'V','158961','Aaaa','Aaaa','4121338032','Direccion','2001-09-22','Masculino','DES','SALUDABLE'),(28,'V','2000001','Argentina','Apellido_1','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(29,'V','2000002','Editado','Modificado','04123454320','en su casa','2002-02-20','Masculino','DES','SALUDABLE'),(30,'V','2000003','Chile','Apellido_3','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(31,'V','2000004','Colombia','Apellido','04121338031','Esto es una direccion pero editarda','2000-01-01','Masculino','DES','SALUDABLE'),(34,'V','2000007','Uruguay','Apellido_7','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(35,'V','2000008','Venezuela','Apellido_8','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(36,'V','2000009','Ecuador','Apellido','04121338031','Esto es una direccion pero editarda','2000-02-04','Femenino','DES','SALUDABLE'),(37,'V','2000010','Bolivia','Apellid','04121338031','Direccion generica','2000-01-01','Masculino','DES','SALUDABLE'),(38,'V','2000011','Paraguay','Apellido_11','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(39,'V','2000012','Panamá','Apellido_12','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(42,'V','2000015','El Salvador','Apellido_15','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(45,'V','2000018','Cuba','Apegkhdfkghdflg','04121338031','Direccion generica','2000-01-01','Femenino','DES','SALUDABLE'),(46,'V','20000190','República','Apellido','04121338031','Direccion generica','2000-01-01','Femenino','DES','SALUDABLE'),(47,'V','2000020','Puerto Rico','Apellido_20','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(48,'V','2000021','Canadá','Apellido_21','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(49,'V','2000022','España','Apellido_22','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(50,'V','2000023','Francia','Apellido_23','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(51,'V','2000024','Italia','Apellido_24','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(52,'V','2000025','Alemania','Apellido_25','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(53,'V','2000026','Portugal','Apellido_26','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(54,'V','2000027','Grecia','Apellido_27','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(55,'V','2000028','Rusia','Apellido_28','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(56,'V','2000029','China','Apellido_29','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(57,'V','2000030','Japón','Apellido_30','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(58,'V','2000031','Corea del Sur','Apellido_31','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(59,'V','2000032','India','Apellido_32','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(60,'V','2000033','Australia','Apellido_33','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(61,'V','2000034','Nueva Zelanda','Apellido_34','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(62,'V','2000035','Egipto','Apellido_35','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(63,'V','2000036','Sudáfrica','Apellido_36','04121338031','Dirección genérica','2000-01-01','Femenino','DES','SALUDABLE'),(64,'V','2000037','Nigeria','Apellido_37','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(65,'V','2000038','Kenia','Apellido_38','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(66,'V','2000039','Senegal','Apellido_39','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(67,'V','2000040','Túnez','Apellido_40','04121338031','Dirección genérica','2000-01-01','Femenino','ACT','SALUDABLE'),(68,'V','2000041','Argentina','Apellido_41','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(69,'V','2000042','Brasil','Apellido_42','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(70,'V','2000043','Chile','Apellido_43','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(71,'V','2000044','Colombia','Apellido_44','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(72,'V','2000045','México','Apellido_45','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(73,'V','2000046','Perú','Apellido_46','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(74,'V','2000047','Uruguay','Apellido_47','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(75,'V','2000048','Venezuela','Apellido_48','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(76,'V','2000049','Ecuador','Apellido_49','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(77,'V','2000050','Bolivia','Apellido_50','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(78,'V','2000051','Paraguay','Apellido_51','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(79,'V','2000052','Panamá','Apellido_52','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(80,'V','2000053','Costa Rica','Apellido_53','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(81,'V','2000054','Guatemala','Apellido_54','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(82,'V','2000055','El Salvador','Apellido_55','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(83,'V','2000056','Honduras','Apellido_56','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(84,'V','2000057','Nicaragua','Apellido_57','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(85,'V','2000058','Cuba','Apellido_58','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(86,'V','20000590','República','Apellido','04121338031','Direccin genrica','2000-01-01','Masculino','ACT','SALUDABLE'),(87,'V','2000060','Puerto Rico','Apellido_60','04121338031','Dirección genérica','2000-01-01','Masculino','ACT','SALUDABLE'),(88,'V','1480973','Liam','Hendrick','04128649495','En su casa ','1997-06-28','Femenino','DES','SALUDABLE'),(89,'V','341234','Gol','Peterson','04123433454','California','2000-06-05','Masculino','DES','CRONICO'),(90,'V','20321830','Yuletxy','Colmenarez','04128892449','El tocuyo','1992-02-10','Femenino','ACT','SALUDABLE'),(91,'V','344233','Perdo','Msdms','04142322323','en su cas','2009-11-11','Masculino','ACT','SALUDABLE'),(92,'V','3055414','Mdfgdf','Ssdds','04142320233','SMDSDMDS','2007-02-11','Femenino','ACT','SALUDABLE'),(93,'V','303439','Awqwkq','Qmasm','04123434322','wenew sdnsd','2025-09-02','Masculino','ACT','SALUDABLE'),(94,'V','3055415','Adsad','Asdsd','04122343323','em sfdnfdhf','2025-09-15','Femenino','ACT','SALUDABLE'),(98,'V','3722999','Pedro','Perez','04123454327','en su casa','2002-02-20','Masculino','ACT','SALUDABLE'),(100,'V','534534','Wewd','Xas','04122323222','en su casssa','2001-09-30','Masculino','ACT','SALUDABLE'),(102,'V','13197426','Piolin','Paralo','04122323212','wdqwdqwd','2000-02-21','Masculino','DES','SALUDABLE'),(103,'V','1212122','Colombia','Apellido','04141322333','Direccin genrica','2026-03-24','Masculino','DES','SALUDABLE'),(104,'V','30554144','Dixon','Bastias','04142232333','En el Tocuyo','2004-10-07','Masculino','ACT','SALUDABLE'),(105,'V','23421321','Venezuela','Apellido','04121338031','wewewqwew','2001-03-23','Masculino','ACT','SALUDABLE'),(106,'V','6789089','Venezuela','Apellido','04121338031','wewewqwew','2009-03-31','Femenino','DES','SALUDABLE'),(107,'V','5665566','Venezuela','Apellido','04121338031','wewewqwew','2000-03-17','Femenino','DES','SALUDABLE'),(108,'V','3055413','Asss','Sddds','04123222222','En su casa','2011-06-16','Masculino','DES','SALUDABLE'),(109,'V','12121212','Wilmer','Baez','04123232323','en su casa','2000-07-29','Masculino','ACT','SALUDABLE'),(110,'V','1414141','Culeba','Bastias','04123232323','en su casa','2000-07-30','Femenino','ACT','SALUDABLE'),(113,'V','1101110','Xxxxx','Xxxxx','04121338031','Xxxxx sff dgdsg dgd','2026-07-07','Masculino','ACT','SALUDABLE'),(117,'V','1223232','Dsdsss','Sdsdsds','04142323232','Esto es una direccion','2000-07-22','Femenino','ACT','SALUDABLE'),(119,'V','30665155','Wilmer','Hernadéz','04121338031','En el Tocuyo','2011-08-27','Masculino','ACT','SALUDABLE'),(121,'V','30665150','Wilmer','Hernadéz','04121338031','En el Tocuyo','2011-08-27','Masculino','ACT','SALUDABLE'),(122,'V','30669149','Wilmer','Hernadéz','04121338031','En el Tocuyo','2011-08-27','Masculino','ACT','SALUDABLE'),(124,'V','36669148','Wilmeruiu','Hernadéz','04121338031','En el Tocuyo','2011-08-27','Masculino','ACT','SALUDABLE'),(127,'E','1223239','Asss','Bastias','04123232323','Esto es una direccion pero editarda','2000-09-02','Femenino','ACT','SALUDABLE'),(131,'V','40554145','Wilmer','Hernadéz','04123232323','Esto es una direccion pero editarda','1990-09-02','Masculino','ACT','SALUDABLE'),(132,'V','4098923','Nombre Crrecto','Dssdsd','04144223230','Es un pacienter','2000-09-01','Masculino','DES','SALUDABLE');
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pago`
--

DROP TABLE IF EXISTS `pago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pago` (
  `id_pago` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pago`
--

LOCK TABLES `pago` WRITE;
/*!40000 ALTER TABLE `pago` DISABLE KEYS */;
INSERT INTO `pago` VALUES (5,'Efectivo'),(6,'Pago Movil'),(7,'Transferencia'),(8,'Divisas');
/*!40000 ALTER TABLE `pago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagodefactura`
--

DROP TABLE IF EXISTS `pagodefactura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagodefactura` (
  `id_pagoDeFactura` int(11) NOT NULL AUTO_INCREMENT,
  `id_pago` int(11) NOT NULL,
  `id_factura` int(11) NOT NULL,
  `referencia` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci DEFAULT NULL,
  `monto` float(12,2) NOT NULL,
  PRIMARY KEY (`id_pagoDeFactura`),
  KEY `id_pago` (`id_pago`),
  KEY `id_factura` (`id_factura`),
  CONSTRAINT `pagodefactura_ibfk_1` FOREIGN KEY (`id_pago`) REFERENCES `pago` (`id_pago`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `pagodefactura_ibfk_2` FOREIGN KEY (`id_factura`) REFERENCES `factura` (`id_factura`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagodefactura`
--

LOCK TABLES `pagodefactura` WRITE;
/*!40000 ALTER TABLE `pagodefactura` DISABLE KEYS */;
INSERT INTO `pagodefactura` VALUES (247,5,213,'0',0.00),(248,5,249,'0',791666.69);
/*!40000 ALTER TABLE `pagodefactura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patologia`
--

DROP TABLE IF EXISTS `patologia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patologia` (
  `id_patologia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_patologia` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `estado` varchar(12) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_patologia`),
  UNIQUE KEY `nombre_patologia` (`nombre_patologia`)
) ENGINE=InnoDB AUTO_INCREMENT=218 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patologia`
--

LOCK TABLES `patologia` WRITE;
/*!40000 ALTER TABLE `patologia` DISABLE KEYS */;
INSERT INTO `patologia` VALUES (2,'DIABETES TIPO 1','DES'),(3,'DIABETES TIPO 2','ACT'),(5,'EPOC','DES'),(6,'ARTRITIS REUMATOIDE','DES'),(7,'ENFERMEDAD CELÍACA','DES'),(8,'OBESIDAD','ACT'),(11,'ENFERMEDAD DE CROHN','ACT'),(12,'COLITIS ULCEROSA','ACT'),(13,'ASMA','1'),(14,'Patologia','ACT'),(15,'Algo','ACT'),(16,'HIPERTIROIDISMO','ACT'),(17,'OSTEOPOROSIS','ACT'),(19,'MIGRAÑA','ACT'),(20,'ALZHEIMER','ACT'),(186,'Hipertensión','ACT'),(189,'Bronquitis','ACT'),(190,'Neumonía','ACT'),(192,'Gastritis','ACT'),(193,'Hepatitis A','ACT'),(194,'Hepatitis B','ACT'),(195,'Anemia','ACT'),(196,'Artritis','ACT'),(198,'Epilepsia','ACT'),(199,'Depresión','ACT'),(200,'Ansiedad','ACT'),(201,'Dermatitis','ACT'),(202,'Sinusitis','ACT'),(203,'COVID-19','ACT'),(204,'Tuberculosis','ACT'),(205,'Insuficiencia renal','ACT'),(207,'Generica','ACT'),(211,'[value-2]','[value-3]'),(212,'Sas sdsdh','ACT'),(213,'Xcxc x','ACT'),(214,'OBESIDAD jdfsdf','ACT'),(215,'Sas sdsd','ACT'),(216,'ASasasasas','ACT'),(217,'Wwwwww','ACT');
/*!40000 ALTER TABLE `patologia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patologiadepaciente`
--

DROP TABLE IF EXISTS `patologiadepaciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patologiadepaciente` (
  `id_patologiaDePaciente` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) DEFAULT NULL,
  `id_patologia` int(11) DEFAULT NULL,
  `fecha_registro` datetime NOT NULL,
  PRIMARY KEY (`id_patologiaDePaciente`),
  KEY `id_paciente` (`id_paciente`),
  KEY `id_patologia` (`id_patologia`),
  CONSTRAINT `id_paciente ` FOREIGN KEY (`id_paciente`) REFERENCES `paciente` (`id_paciente`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `id_patologia` FOREIGN KEY (`id_patologia`) REFERENCES `patologia` (`id_patologia`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patologiadepaciente`
--

LOCK TABLES `patologiadepaciente` WRITE;
/*!40000 ALTER TABLE `patologiadepaciente` DISABLE KEYS */;
INSERT INTO `patologiadepaciente` VALUES (16,23,13,'2025-04-02 20:13:12'),(17,23,13,'2025-04-02 20:13:46'),(18,26,15,'2025-05-15 17:26:49'),(19,26,13,'2025-05-15 18:18:42'),(20,24,13,'2025-05-15 18:18:51'),(21,25,13,'2025-05-15 18:18:51'),(102,25,5,'2025-04-01 10:15:00'),(157,28,8,'2025-04-03 09:30:00'),(176,70,20,'2025-04-20 16:30:00'),(178,49,17,'2025-04-17 13:05:00'),(179,55,16,'2025-04-16 11:35:00'),(180,47,13,'2025-04-15 10:10:00'),(181,48,15,'2025-04-14 09:45:00'),(183,28,11,'2025-04-12 08:50:00'),(194,27,2,'2025-04-10 12:00:00'),(195,27,6,'2025-04-09 15:25:00'),(202,29,14,'2025-04-06 16:00:00'),(207,28,8,'2025-04-03 09:30:00'),(208,26,3,'2025-04-04 11:20:00'),(209,62,6,'2025-05-15 19:42:53'),(210,59,20,'2025-05-15 19:43:28'),(211,60,11,'2025-05-15 19:43:28'),(212,87,2,'2025-05-15 19:43:56'),(214,87,20,'2025-05-15 19:44:11'),(215,86,7,'2025-05-15 19:44:11'),(216,29,205,'2025-05-15 19:44:21'),(218,51,14,'2025-05-15 19:44:51'),(219,58,14,'2025-05-15 19:44:51'),(220,46,14,'2025-05-15 19:45:12'),(222,25,6,'2025-06-10 10:11:51'),(223,25,8,'2025-06-10 10:11:51'),(224,25,5,'2025-06-10 20:07:54'),(225,25,6,'2025-06-10 20:07:54'),(226,25,7,'2025-06-10 20:07:54'),(227,25,8,'2025-06-10 20:07:54'),(229,25,5,'2025-06-19 20:29:30'),(230,25,6,'2025-06-19 20:29:30'),(231,25,7,'2025-06-19 20:29:30'),(232,25,8,'2025-06-19 20:29:30'),(234,25,186,'2025-06-19 20:29:30'),(235,25,190,'2025-06-19 20:29:30'),(236,25,192,'2025-06-19 20:29:30'),(237,89,5,'2025-06-27 19:24:28'),(238,89,7,'2025-06-27 19:24:28'),(239,25,5,'2025-09-25 20:24:37'),(240,25,7,'2025-09-25 20:24:37'),(241,25,5,'2025-10-03 11:23:02'),(242,25,7,'2025-10-03 11:23:02'),(243,25,5,'2025-10-03 11:23:41'),(244,25,7,'2025-10-03 11:23:41'),(245,26,5,'2025-11-03 14:23:45'),(246,102,5,'2025-11-03 14:37:35'),(247,23,20,'2025-11-03 14:46:59'),(248,102,5,'2025-11-03 15:00:02'),(249,102,11,'2025-11-03 15:01:59'),(250,102,190,'2025-11-03 17:18:04'),(251,102,17,'2025-11-04 10:07:56'),(252,102,7,'2025-11-04 13:11:48'),(253,102,5,'2025-11-04 13:41:16'),(254,102,5,'2025-11-04 17:31:58'),(255,102,5,'2025-11-04 18:23:02'),(256,104,214,'2026-08-23 00:00:00'),(257,104,213,'2026-08-23 00:00:00'),(258,104,214,'2026-08-23 00:00:00'),(259,104,213,'2026-08-23 00:00:00'),(260,92,203,'2026-08-23 00:00:00'),(261,92,202,'2026-08-23 00:00:00'),(262,92,201,'2026-08-23 00:00:00'),(263,104,214,'2026-08-23 00:00:00'),(264,104,213,'2026-08-23 00:00:00'),(265,104,205,'2026-08-23 00:00:00'),(266,104,203,'2026-08-23 00:00:00'),(267,104,201,'2026-08-23 00:00:00'),(292,104,216,'2026-08-27 00:00:00'),(293,104,215,'2026-08-27 00:00:00'),(294,104,214,'2026-08-27 00:00:00'),(295,104,213,'2026-08-27 00:00:00'),(296,104,212,'2026-08-27 00:00:00'),(297,104,207,'2026-08-27 00:00:00'),(298,104,205,'2026-08-27 00:00:00'),(299,104,203,'2026-08-27 00:00:00'),(300,104,216,'2026-08-27 00:00:00'),(301,104,215,'2026-08-27 00:00:00'),(302,104,214,'2026-08-27 00:00:00'),(303,104,213,'2026-08-27 00:00:00'),(304,104,212,'2026-08-27 00:00:00'),(305,104,207,'2026-08-27 00:00:00'),(306,104,205,'2026-08-27 00:00:00'),(307,104,203,'2026-08-27 00:00:00'),(308,23,216,'2026-08-29 00:00:00'),(309,23,215,'2026-08-29 00:00:00'),(310,23,214,'2026-08-29 00:00:00');
/*!40000 ALTER TABLE `patologiadepaciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal`
--

DROP TABLE IF EXISTS `personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal` (
  `id_personal` int(11) NOT NULL AUTO_INCREMENT,
  `nacionalidad` varchar(5) NOT NULL,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `tipodecategoria` varchar(25) NOT NULL,
  `id_especialidad` int(11) DEFAULT NULL,
  `usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_personal`),
  UNIQUE KEY `cedula` (`cedula`),
  KEY `id_especialidad` (`id_especialidad`),
  CONSTRAINT `personal_ibfk_1` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidad` (`id_especialidad`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal`
--

LOCK TABLES `personal` WRITE;
/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
INSERT INTO `personal` VALUES (18,'V','30554053','Wilmero','Baez','04145378608','Administrador',NULL,1),(19,'V','1232233','David','Carlos','04142323233','',7,42),(20,'V','12123343','Carlos','Garcia','04244546565','',7,43),(21,'V','12020333','Ana','Bracho','04122323422','',6,45),(22,'V','6755654','Julian','Valdez','04122323212','',4,46),(23,'V','867548','Jaun','Edlkfjfdsk','04243943432','',5,49),(24,'V','1223211','Auto','Auto','04122232323','Administrador',NULL,50),(25,'V','5675324','Alen','Alenrere','04123434343','Administrador',NULL,51),(29,'V','2000002','Editado','Modificado','04123454320','',NULL,47),(32,'V','30554145','Dixon','Bastias','04141232333','Doctor',5,55),(36,'V','55555555','Dixon','Asddd','04142323232','Doctor',3,60),(41,'V','1223232','Juan','Lara','04121338031','Doctor',3,66),(46,'V','2000009','Estado Uidide','Silva','04142323232','Doctor',8,71),(49,'V','40554145','Estado Uidide','Silva','04121338031','Doctor',5,74),(50,'V','12232321','Estado Uidide','Asddd','04142323232','Doctor',4,75),(51,'V','2123123','Tptotura','Asddd','04121338031','Doctor',5,76),(52,'V','12203232','Dixon','Silva','04121338031','Doctor',5,77),(53,'V','12293232','Dixon','Silva','04121338031','Doctor',5,78),(54,'V','11293227','Dixon','Silva','04121338031','Doctor',5,79),(55,'V','1123227','Youuyuy','Silva','04121338031','Doctor',5,80),(56,'V','41554145','Asss','Baez','04123232323','Doctor',NULL,88),(57,'V','31554145','Asss','Baez','04123232323','Doctor',NULL,89),(58,'V','81554145','Asss','Baez','04123232323','Doctor',NULL,90),(59,'V','1554145','Asss','Baez','04123232323','Doctor',NULL,91),(60,'V','66548141','Asss','Baez','04123232323','Doctor',NULL,96),(61,'V','40301111','Yososo','Yoso','04142323232','Doctor',8,97),(62,'V','40554144','Doctor','Prueba','04123232323','Doctor',7,98);
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_has_serviciomedico`
--

DROP TABLE IF EXISTS `personal_has_serviciomedico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_has_serviciomedico` (
  `personal_id_personal` int(11) NOT NULL,
  `serviciomedico_id_servicioMedico` int(11) NOT NULL,
  PRIMARY KEY (`personal_id_personal`,`serviciomedico_id_servicioMedico`),
  KEY `fk_personal_has_serviciomedico_serviciomedico1_idx` (`serviciomedico_id_servicioMedico`),
  KEY `fk_personal_has_serviciomedico_personal1_idx` (`personal_id_personal`),
  CONSTRAINT `personal_has_serviciomedico_ibfk_1` FOREIGN KEY (`serviciomedico_id_servicioMedico`) REFERENCES `serviciomedico` (`id_servicioMedico`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `personal_has_serviciomedico_ibfk_2` FOREIGN KEY (`personal_id_personal`) REFERENCES `personal` (`id_personal`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_has_serviciomedico`
--

LOCK TABLES `personal_has_serviciomedico` WRITE;
/*!40000 ALTER TABLE `personal_has_serviciomedico` DISABLE KEYS */;
INSERT INTO `personal_has_serviciomedico` VALUES (18,25),(19,24),(19,26),(19,29),(19,30),(19,32),(19,33),(19,36),(20,24),(20,27),(20,28),(20,31),(22,25),(23,23),(53,24),(53,26),(61,24),(62,24),(62,40);
/*!40000 ALTER TABLE `personal_has_serviciomedico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `rif` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `telefono` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(40) NOT NULL,
  `direccion` text NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id_proveedor`),
  UNIQUE KEY `rif` (`rif`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (6,'Juan Jose','281500045','04121338909','depanajuaner@gmail.com','en su casa','DES'),(7,'Ricardo Perez','296236571','04124466999','sisisi@gmail.com','hfygh','ACT'),(8,'Luis Empresa','J122334','0424354556','luis12345@gmail.com','El Tocuyo','ACT'),(11,'Juanx','ffreer','04122323232','dix2334antias@gmail.com','dffdf','ACT'),(12,'Tunal','J-34345344','04123232323','depanajuaner@gmail.com','Estados unidos','DES'),(13,'Wilmer','J-34345343','04142323232','correo@gmail.com','Estados unidos','ACT'),(14,'Provedi','J-12122333','04123232323','correo@gmail.com','Es una diraccion','ACT');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `serviciomedico`
--

DROP TABLE IF EXISTS `serviciomedico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviciomedico` (
  `id_servicioMedico` int(11) NOT NULL AUTO_INCREMENT,
  `id_categoria` int(11) NOT NULL,
  `precio` float(12,2) NOT NULL,
  `estado` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tipo` varchar(25) NOT NULL,
  PRIMARY KEY (`id_servicioMedico`),
  KEY `id_categoria` (`id_categoria`),
  CONSTRAINT `serviciomedico_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria_servicio` (`id_categoria`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `serviciomedico`
--

LOCK TABLES `serviciomedico` WRITE;
/*!40000 ALTER TABLE `serviciomedico` DISABLE KEYS */;
INSERT INTO `serviciomedico` VALUES (22,9,2200.00,'ACT','Examenes'),(23,100,1500.00,'ACT','Cita'),(24,1,3000.00,'DES','Cita'),(25,101,1000.00,'ACT','Examenes'),(26,2,120.00,'DES','Cita'),(27,2,123.00,'DES',''),(28,1,31395.00,'DES',''),(29,1,16905.00,'DES',''),(30,1,169.05,'DES',''),(31,101,12.00,'DES',''),(32,1,479.78,'DES',''),(33,100,1.07,'DES',''),(34,104,24.95,'DES','Cita'),(35,103,60.66,'ACT','Cita'),(36,102,4681.00,'ACT','Examenes'),(37,105,5.48,'ACT','Examenes'),(38,9,100.00,'ACT','Cita'),(39,110,12.00,'ACT','Cita'),(40,115,2.00,'ACT','Examenes');
/*!40000 ALTER TABLE `serviciomedico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicios_hospitalizacion`
--

DROP TABLE IF EXISTS `servicios_hospitalizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servicios_hospitalizacion` (
  `id_detalle` int(11) NOT NULL AUTO_INCREMENT,
  `id_hospitalizacion` int(11) NOT NULL,
  `id_servicioMedico` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  PRIMARY KEY (`id_detalle`),
  KEY `id_hospitalizacion` (`id_hospitalizacion`,`id_servicioMedico`),
  KEY `id_servicioMedico` (`id_servicioMedico`),
  CONSTRAINT `servicios_hospitalizacion_ibfk_1` FOREIGN KEY (`id_hospitalizacion`) REFERENCES `hospitalizacion` (`id_hospitalizacion`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `servicios_hospitalizacion_ibfk_2` FOREIGN KEY (`id_servicioMedico`) REFERENCES `serviciomedico` (`id_servicioMedico`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios_hospitalizacion`
--

LOCK TABLES `servicios_hospitalizacion` WRITE;
/*!40000 ALTER TABLE `servicios_hospitalizacion` DISABLE KEYS */;
INSERT INTO `servicios_hospitalizacion` VALUES (17,48,36,2),(18,48,25,1);
/*!40000 ALTER TABLE `servicios_hospitalizacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sintomas`
--

DROP TABLE IF EXISTS `sintomas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sintomas` (
  `id_sintomas` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) NOT NULL,
  `estado` varchar(5) NOT NULL,
  PRIMARY KEY (`id_sintomas`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sintomas`
--

LOCK TABLES `sintomas` WRITE;
/*!40000 ALTER TABLE `sintomas` DISABLE KEYS */;
INSERT INTO `sintomas` VALUES (5,'Disnea','DES'),(6,'Fiebre','DES'),(7,'Vomito','DES'),(8,'Dolor de cabeza','DES'),(9,'Malestar general','ACT'),(10,'Inchazon','ACT'),(11,'Enrojecimiento','ACT'),(12,'Piel Amarilla','ACT'),(13,'Dolor de higado','DES'),(14,'Encias sangrantes','DES'),(15,'sintoma','DES'),(16,'Xxxxxx','DES'),(17,'Sin n n','DES'),(19,'Wilmer','ACT'),(20,'Sods','ACT'),(21,'Sudo','DES');
/*!40000 ALTER TABLE `sintomas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sintomas_control`
--

DROP TABLE IF EXISTS `sintomas_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sintomas_control` (
  `id_sintomas_control` int(11) NOT NULL AUTO_INCREMENT,
  `id_sintomas` int(11) NOT NULL,
  `id_control` int(11) NOT NULL,
  PRIMARY KEY (`id_sintomas_control`),
  KEY `id_sintomas` (`id_sintomas`),
  KEY `id_control` (`id_control`),
  CONSTRAINT `sintomas_control_ibfk_1` FOREIGN KEY (`id_sintomas`) REFERENCES `sintomas` (`id_sintomas`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `sintomas_control_ibfk_2` FOREIGN KEY (`id_control`) REFERENCES `control` (`id_control`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sintomas_control`
--

LOCK TABLES `sintomas_control` WRITE;
/*!40000 ALTER TABLE `sintomas_control` DISABLE KEYS */;
INSERT INTO `sintomas_control` VALUES (37,5,26),(38,10,26),(39,8,26),(40,8,27),(41,9,27),(42,7,27),(43,5,28),(44,6,28),(45,7,28),(46,5,29),(47,6,29),(48,8,29),(49,5,30),(50,6,30),(51,6,31),(52,8,31),(53,6,32),(54,8,32),(55,6,33),(56,8,33),(57,6,34),(58,8,34),(59,6,40),(60,6,42),(61,9,42),(62,6,43),(63,6,45),(64,8,46),(65,6,47),(66,8,48),(67,6,49),(68,8,50),(69,8,51),(70,6,52),(71,6,53),(72,6,54),(73,6,55),(74,9,55),(75,6,55),(76,8,55),(77,20,62),(78,19,62),(79,20,63),(80,19,63),(81,19,64),(82,11,64),(83,9,64),(84,20,65),(85,12,65),(86,20,66),(87,12,66),(88,11,66),(89,20,71),(90,19,71),(91,12,71),(92,20,72),(93,12,72),(94,9,72);
/*!40000 ALTER TABLE `sintomas_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `tasa_morbilidad`
--

DROP TABLE IF EXISTS `tasa_morbilidad`;
/*!50001 DROP VIEW IF EXISTS `tasa_morbilidad`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `tasa_morbilidad` AS SELECT
 1 AS `nombre_patologia`,
  1 AS `casos`,
  1 AS `tasa_por_1000` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_detalle_entradas`
--

DROP TABLE IF EXISTS `view_detalle_entradas`;
/*!50001 DROP VIEW IF EXISTS `view_detalle_entradas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_detalle_entradas` AS SELECT
 1 AS `fechaDeVencimiento`,
  1 AS `id_entradaDeInsumo`,
  1 AS `imagen`,
  1 AS `nombre`,
  1 AS `descripcion`,
  1 AS `marca`,
  1 AS `medida`,
  1 AS `precio`,
  1 AS `stockMinimo`,
  1 AS `iva`,
  1 AS `id_insumo_e`,
  1 AS `id_entrada`,
  1 AS `id_proveedor`,
  1 AS `numero_de_lote`,
  1 AS `fechaDeIngreso`,
  1 AS `estado`,
  1 AS `cantidad_entrada`,
  1 AS `precio_entrada`,
  1 AS `proveedor`,
  1 AS `correo` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_factura`
--

DROP TABLE IF EXISTS `view_factura`;
/*!50001 DROP VIEW IF EXISTS `view_factura`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_factura` AS SELECT
 1 AS `id_factura`,
  1 AS `fecha`,
  1 AS `total`,
  1 AS `id_cliente`,
  1 AS `nombre_p`,
  1 AS `apellido_p`,
  1 AS `nacionalidad`,
  1 AS `cedula_p` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_paciente_hospitalizado`
--

DROP TABLE IF EXISTS `view_paciente_hospitalizado`;
/*!50001 DROP VIEW IF EXISTS `view_paciente_hospitalizado`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_paciente_hospitalizado` AS SELECT
 1 AS `indice`,
  1 AS `id_hospitalizacion`,
  1 AS `fecha_hora_inicio`,
  1 AS `precio_horas`,
  1 AS `fecha_hora_final`,
  1 AS `total`,
  1 AS `id_control`,
  1 AS `diagnostico`,
  1 AS `historiaclinica`,
  1 AS `id_paciente`,
  1 AS `nacionalidad`,
  1 AS `cedula`,
  1 AS `nombre`,
  1 AS `apellido`,
  1 AS `id_usuario`,
  1 AS `nombredoc`,
  1 AS `apellidodoc`,
  1 AS `estado_usuario`,
  1 AS `estado_hospitalizacion` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_resumen_insumos`
--

DROP TABLE IF EXISTS `view_resumen_insumos`;
/*!50001 DROP VIEW IF EXISTS `view_resumen_insumos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_resumen_insumos` AS SELECT
 1 AS `id_insumo`,
  1 AS `imagen`,
  1 AS `nombre`,
  1 AS `descripcion`,
  1 AS `marca`,
  1 AS `medida`,
  1 AS `precio`,
  1 AS `stockMinimo`,
  1 AS `iva`,
  1 AS `disponible`,
  1 AS `estado_insumo` */;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'bd'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `limpiar_reservas_vencidas` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8mb4 */ ;;
/*!50003 SET character_set_results = utf8mb4 */ ;;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = '+00:00' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `limpiar_reservas_vencidas` ON SCHEDULE EVERY 1 MINUTE STARTS '2026-06-03 16:08:25' ON COMPLETION NOT PRESERVE ENABLE DO UPDATE cita 
  SET estado = 'Expirado' 
  WHERE estado = 'Reservado' 
    AND creado_en < NOW() - INTERVAL 5 MINUTE */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'bd'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DescontarLotes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `DescontarLotes`(IN `insumo_id` INT, IN `cantidad_requerida` INT)
BEGIN




    DECLARE cantidad_restante INT DEFAULT cantidad_requerida;




    DECLARE lote_id INT;




    DECLARE lote_cantidad INT;









    DECLARE done INT DEFAULT FALSE;




    DECLARE lote_cursor CURSOR FOR




        SELECT ei.id_entradaDeInsumo, ei.cantidad_disponible




        FROM entrada_insumo ei INNER JOIN entrada e 




        ON e.id_entrada = ei.id_entrada




        WHERE ei.id_insumo = insumo_id AND ei.cantidad_disponible > 0




        ORDER BY e.fechaDeIngreso ASC; 








    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;









    OPEN lote_cursor;









    lectura_lote: LOOP




        FETCH lote_cursor INTO lote_id, lote_cantidad;




        IF done THEN




            LEAVE lectura_lote;




        END IF;









        IF cantidad_restante <= lote_cantidad THEN




            UPDATE entrada_insumo




            SET cantidad_disponible = cantidad_disponible - cantidad_restante




            WHERE id_entradaDeInsumo = lote_id;




            SET cantidad_restante = 0;




            LEAVE lectura_lote;




        ELSE




            UPDATE entrada_insumo




            SET cantidad_disponible = 0




            WHERE id_entradaDeInsumo = lote_id;




            SET cantidad_restante = cantidad_restante - lote_cantidad;




        END IF;




    END LOOP;









    CLOSE lote_cursor;




END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devolver_cantidad_insumos` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `devolver_cantidad_insumos`(IN `id_factura` INT)
BEGIN




    DECLARE done INT DEFAULT FALSE;




    DECLARE entrada_id INT; 



    DECLARE cantidad_en_factura  INT;









    



    DECLARE insumo_cursor CURSOR FOR 




        SELECT id_entradaDeInsumo, cantidad FROM bd.factura_has_inventario WHERE factura_id_factura = id_factura;









    



    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;









    



    OPEN insumo_cursor;









    



    read_loop: LOOP




        FETCH insumo_cursor INTO entrada_id, cantidad_en_factura;









        IF done THEN




            LEAVE read_loop; 



        END IF;




        




        update bd.entrada_insumo set cantidad_disponible = cantidad_disponible + cantidad_en_factura where id_entradaDeInsumo = entrada_id;




    END LOOP;









    



    CLOSE insumo_cursor;




END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `devolver_insumo_hospitalizacion` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `devolver_insumo_hospitalizacion`(IN `p_id_insumo` INT, IN `p_cantidad` INT)
BEGIN
    DECLARE v_idEntrada INT;

    
    SELECT ei.id_entradaDeInsumo
    INTO v_idEntrada
    FROM entrada_insumo ei
    WHERE ei.id_insumo = p_id_insumo
    ORDER BY ei.fechaDeVencimiento DESC
    LIMIT 1;

    
    UPDATE entrada_insumo
    SET cantidad_disponible = p_cantidad
    WHERE id_entradaDeInsumo = v_idEntrada;

    
    SELECT v_idEntrada AS idEntrada_actualizada;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_entrada` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_entrada`(IN `id_insumo` INT, IN `id_proveedor` INT, IN `fechaDeIngreso` DATE, IN `fechaDeVecimiento` DATE, IN `precio` FLOAT, IN `cantidad` INT, IN `lote` TEXT)
BEGIN




    declare id_entrada int;




    




    INSERT INTO entrada VALUES (null, id_proveedor, lote, fechaDeIngreso, 'ACT');




    set id_entrada =  last_insert_id();




    




    INSERT INTO entrada_insumo VALUES (null, id_insumo, id_entrada,fechaDeVecimiento,precio, cantidad, cantidad);




END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insert_insumo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_insumo`(IN `imagen` TEXT, IN `nombre` TEXT, IN `id_proveedor` INT, IN `descripcion` TEXT, IN `fechaDeIngreso` DATE, IN `fechaDeVecimiento` DATE, IN `precio` FLOAT, IN `cantidad` INT, IN `stockMinimo` INT, IN `lote` TEXT, IN `marca` TEXT, IN `medida` TEXT, IN `iva` BOOLEAN)
BEGIN




	declare id_insumo int;




    declare id_entrada int;




    




	INSERT INTO insumo VALUES (null, imagen, nombre, descripcion, marca, medida, precio , 'ACT',stockMinimo, iva);




    set id_insumo = last_insert_id();




    




    INSERT INTO entrada VALUES (null, id_proveedor, lote, fechaDeIngreso, 'ACT');




    set id_entrada =  last_insert_id();




    




    INSERT INTO entrada_insumo VALUES (null, id_insumo, id_entrada,fechaDeVecimiento,precio, cantidad, cantidad);




END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `distribucion_edad_genero`
--

/*!50001 DROP VIEW IF EXISTS `distribucion_edad_genero`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `distribucion_edad_genero` AS select `sub`.`rango_edad` AS `rango_edad`,sum(case when `sub`.`genero` = 'masculino' then `sub`.`cantidad` else 0 end) AS `masculino`,sum(case when `sub`.`genero` = 'femenino' then `sub`.`cantidad` else 0 end) AS `femenino`,sum(`sub`.`cantidad`) AS `total`,(select count(0) from `paciente` where `paciente`.`genero` = 'masculino') AS `total_masculino`,(select count(0) from `paciente` where `paciente`.`genero` = 'femenino') AS `total_femenino` from (select case when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 0 and 12 then '0-12' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 13 and 19 then '13-19' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 20 and 35 then '20-35' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 36 and 50 then '36-50' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 51 and 65 then '51-65' else '66+' end AS `rango_edad`,`paciente`.`genero` AS `genero`,count(0) AS `cantidad` from `paciente` group by case when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 0 and 12 then '0-12' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 13 and 19 then '13-19' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 20 and 35 then '20-35' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 36 and 50 then '36-50' when timestampdiff(YEAR,`paciente`.`fn`,curdate()) between 51 and 65 then '51-65' else '66+' end,`paciente`.`genero`) `sub` group by `sub`.`rango_edad` order by `sub`.`rango_edad` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `especialidades_solicitadas`
--

/*!50001 DROP VIEW IF EXISTS `especialidades_solicitadas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `especialidades_solicitadas` AS select `cs`.`nombre` AS `especialidad`,`c`.`fecha` AS `fecha`,count(`c`.`id_cita`) AS `total_solicitudes` from ((`cita` `c` join `serviciomedico` `sm` on(`c`.`serviciomedico_id_servicioMedico` = `sm`.`id_servicioMedico`)) join `categoria_servicio` `cs` on(`sm`.`id_categoria` = `cs`.`id_categoria`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `insumos_estadisticas`
--

/*!50001 DROP VIEW IF EXISTS `insumos_estadisticas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `insumos_estadisticas` AS select `i`.`nombre` AS `nombre_insumo`,sum(`df`.`cantidad`) AS `total_usado` from ((`detalle_factura` `df` join `entrada_insumo` `ei` on(`ei`.`id_entradaDeInsumo` = `df`.`entrada_insumo_id_entradaDeInsumo`)) join `insumo` `i` on(`i`.`id_insumo` = `ei`.`id_insumo`)) where `df`.`entrada_insumo_id_entradaDeInsumo` is not null group by `ei`.`id_insumo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `tasa_morbilidad`
--

/*!50001 DROP VIEW IF EXISTS `tasa_morbilidad`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `tasa_morbilidad` AS select `p`.`nombre_patologia` AS `nombre_patologia`,count(distinct `pp`.`id_paciente`) AS `casos`,round(count(distinct `pp`.`id_paciente`) / (select count(0) from `paciente`) * 1000,2) AS `tasa_por_1000` from (`patologiadepaciente` `pp` join `patologia` `p` on(`pp`.`id_patologia` = `p`.`id_patologia`)) group by `pp`.`id_patologia` order by count(distinct `pp`.`id_paciente`) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_detalle_entradas`
--

/*!50001 DROP VIEW IF EXISTS `view_detalle_entradas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_detalle_entradas` AS select `ei`.`fechaDeVencimiento` AS `fechaDeVencimiento`,`ei`.`id_entradaDeInsumo` AS `id_entradaDeInsumo`,`i`.`imagen` AS `imagen`,`i`.`nombre` AS `nombre`,`i`.`descripcion` AS `descripcion`,`i`.`marca` AS `marca`,`i`.`medida` AS `medida`,`i`.`precio` AS `precio`,`i`.`stockMinimo` AS `stockMinimo`,`i`.`iva` AS `iva`,`i`.`id_insumo` AS `id_insumo_e`,`e`.`id_entrada` AS `id_entrada`,`e`.`id_proveedor` AS `id_proveedor`,`e`.`numero_de_lote` AS `numero_de_lote`,`e`.`fechaDeIngreso` AS `fechaDeIngreso`,`e`.`estado` AS `estado`,`ei`.`cantidad_entrante` AS `cantidad_entrada`,`ei`.`precio` AS `precio_entrada`,`p`.`nombre` AS `proveedor`,`p`.`email` AS `correo` from (((`entrada_insumo` `ei` join `insumo` `i` on(`i`.`id_insumo` = `ei`.`id_insumo`)) join `entrada` `e` on(`e`.`id_entrada` = `ei`.`id_entrada`)) join `proveedor` `p` on(`p`.`id_proveedor` = `e`.`id_proveedor`)) where `i`.`estado` = 'ACT' and `ei`.`fechaDeVencimiento` > curdate() order by `ei`.`fechaDeVencimiento` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_factura`
--

/*!50001 DROP VIEW IF EXISTS `view_factura`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_factura` AS select `f`.`id_factura` AS `id_factura`,`f`.`fecha` AS `fecha`,`f`.`total` AS `total`,`f`.`id_cliente` AS `id_cliente`,`p`.`nombre` AS `nombre_p`,`p`.`apellido` AS `apellido_p`,`p`.`nacionalidad` AS `nacionalidad`,`p`.`cedula` AS `cedula_p` from (`factura` `f` join `cliente` `p` on(`p`.`id_cliente` = `f`.`id_cliente`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_paciente_hospitalizado`
--

/*!50001 DROP VIEW IF EXISTS `view_paciente_hospitalizado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_paciente_hospitalizado` AS select row_number() over ( order by `h`.`id_hospitalizacion`) - 1 AS `indice`,`h`.`id_hospitalizacion` AS `id_hospitalizacion`,`h`.`fecha_hora_inicio` AS `fecha_hora_inicio`,`h`.`precio_horas` AS `precio_horas`,`h`.`fecha_hora_final` AS `fecha_hora_final`,`h`.`total` AS `total`,`con`.`id_control` AS `id_control`,`con`.`diagnostico` AS `diagnostico`,`con`.`historiaclinica` AS `historiaclinica`,`pac`.`id_paciente` AS `id_paciente`,`pac`.`nacionalidad` AS `nacionalidad`,`pac`.`cedula` AS `cedula`,`pac`.`nombre` AS `nombre`,`pac`.`apellido` AS `apellido`,`u`.`id_usuario` AS `id_usuario`,`pe`.`nombre` AS `nombredoc`,`pe`.`apellido` AS `apellidodoc`,`u`.`estado` AS `estado_usuario`,`h`.`estado` AS `estado_hospitalizacion` from ((((((`bd`.`hospitalizacion` `h` join `bd`.`paciente` `pac` on(`h`.`id_paciente` = `pac`.`id_paciente`)) join `bd`.`control` `con` on(`con`.`id_control` = (select `con2`.`id_control` from `bd`.`control` `con2` where `con2`.`id_paciente` = `pac`.`id_paciente` and `con2`.`estado` = 'DES' order by `con2`.`id_control` desc limit 1))) join `segurity`.`usuario` `u` on(`con`.`id_usuario` = `u`.`id_usuario`)) join `bd`.`personal` `pe` on(`pe`.`usuario` = `u`.`id_usuario`)) join `bd`.`personal_has_serviciomedico` `psm` on(`psm`.`personal_id_personal` = `pe`.`id_personal`)) join `bd`.`serviciomedico` `sm` on(`sm`.`id_servicioMedico` = `psm`.`serviciomedico_id_servicioMedico`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_resumen_insumos`
--

/*!50001 DROP VIEW IF EXISTS `view_resumen_insumos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_resumen_insumos` AS select `i`.`id_insumo` AS `id_insumo`,`i`.`imagen` AS `imagen`,`i`.`nombre` AS `nombre`,`i`.`descripcion` AS `descripcion`,`i`.`marca` AS `marca`,`i`.`medida` AS `medida`,`i`.`precio` AS `precio`,`i`.`stockMinimo` AS `stockMinimo`,`i`.`iva` AS `iva`,sum(`ei`.`cantidad_disponible`) AS `disponible`,`i`.`estado` AS `estado_insumo` from ((`entrada_insumo` `ei` join `insumo` `i` on(`i`.`id_insumo` = `ei`.`id_insumo`)) join `entrada` `e` on(`e`.`id_entrada` = `ei`.`id_entrada`)) where `e`.`estado` = 'ACT' and `ei`.`fechaDeVencimiento` > curdate() group by `i`.`id_insumo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-31  9:07:47
